/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class playOneTwoThree {

    final static int MAX = 5;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap trang thai:\nq: quit\ns: scissor\np: paper\ns: stone\n");
        String x = input.readLine();
        while (true) {
            if (x.equalsIgnoreCase("q") || x.equalsIgnoreCase("s") || x.equalsIgnoreCase("t") || x.equalsIgnoreCase("p")) {
                break;
            } else {
                System.out.print("Nhap sai! Xin hay nhap lai: ");
                x = input.readLine();
            }
        }
        if (x.equalsIgnoreCase("q")) {
            System.exit(0);
        } else {
            int diemNguoiChoi = 0;
            int diemMayTinh = 0;
            Random rd = new Random();
            int solan = 0;
            while (true) {
                solan++;
                TrangThai player = null;
                TrangThai computer = null;
                switch (x) {
                    case "s":
                    case "S":
                        player = TrangThai.SCISSOR;
                        System.out.println("\nNguoi chon: " + player.getName());
                        break;
                    case "p":
                    case "P":
                        player = TrangThai.PAPER;
                        System.out.println("\nNguoi chon: " + player.getName());
                        break;
                    case "t":
                    case "T":
                        player = TrangThai.STONE;
                        System.out.println("\nNguoi chon: " + player.getName());
                        break;
                    case "q":
                    case "Q":
                        System.exit(0);
                }
                //May tinh chon
                int rdIdx = rd.nextInt(2);
                computer = TrangThai.values()[rdIdx];
                System.out.println("May tinh chon: " + computer.getName());

                //Kiem tra va tinh diem
                String tt1 = TrangThai.PAPER.getName();
                String tt2 = TrangThai.SCISSOR.getName();
                String tt3 = TrangThai.STONE.getName();

                if (player.getName().equals(computer.getName())) {
                    System.out.println("=> Ngang tai ngang suc.");
                } else if (player.getName() == tt1 && computer.getName() == tt2) {
                    System.out.println("=> Oh oh, ban thua roi.");
                    diemMayTinh++;
                } else if (player.getName() == tt2 && computer.getName() == tt1) {
                    System.out.println("=> Chuc mung ban da thang.");
                    diemNguoiChoi++;
                } else if (player.getName() == tt1 && computer.getName() == tt3) {
                    System.out.println("=> Chuc mung ban da thang.");
                    diemNguoiChoi++;
                } else if (player.getName() == tt3 && computer.getName() == tt1) {
                    System.out.println("=> Oh oh, ban thua roi.");
                    diemMayTinh++;
                } else if (player.getName() == tt2 && computer.getName() == tt3) {
                    System.out.println("=> Oh oh, ban thua roi.");
                    diemMayTinh++;
                } else if (player.getName() == tt3 && computer.getName() == tt2) {
                    System.out.println("=> Chuc mung ban da thang.");
                    diemNguoiChoi++;
                }
                //In diem nguoi choi va may tinh
                System.out.println("Diem so cua nguoi choi: " + diemNguoiChoi);
                System.out.println("Diem so cua may tinh: " + diemMayTinh);
                System.out.println("So lan choi: " + solan);
                if (diemNguoiChoi == MAX || diemMayTinh == MAX) {
                    if (kiemTraThangThua(diemNguoiChoi, diemMayTinh)) {
                        System.out.println("=> Nguoi choi thang!!!");
                    } else {
                        System.out.println("=> May tinh thang!!!");
                    }
                    break;
                }

                //Nguoi dung chon tiep
                System.out.print("\n\n====================================\nNguoi dung chon tiep: ");
                x = input.readLine();
            }
        }
    }

    enum TrangThai {
        SCISSOR, PAPER, STONE;
        private int rank;

        public String getName() {
            return this.name();
        }
    };

    public static boolean kiemTraThangThua(int n1, int n2) {
        if (n1 > n2) {
            return true;
        } else {
            return false;
        }
    }

}
