/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhTongHieuTichThuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap so thu nhat: ");
            int x = Integer.parseInt(input.readLine());
            System.out.print("Nhap so thu hai: ");
            int y = Integer.parseInt(input.readLine());
            System.out.println("Cong: "+PhepTinh.CONG.tinh(x, y));
            System.out.println("Tru: "+PhepTinh.TRU.tinh(x, y));
            System.out.println("Nhan: "+PhepTinh.NHAN.tinh(x, y));
            System.out.println("Chia: "+PhepTinh.CHIA.tinh(x, y));
        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    enum PhepTinh {
        CONG, TRU, NHAN, CHIA;

        float tinh(int x, int y) {
            switch (this) {
                case CONG:
                    return (float) (x + y);
                case TRU:
                    return (float) (x - y);
                case NHAN:
                    return (float) (x * y);
                case CHIA:
                    if (y == 0) {
                        throw new ArithmeticException("mau so bang 0");
                    }
                    return (float)x / (float)y;
                default:
                    throw new AssertionError(this);
            }
        }
    };

}
