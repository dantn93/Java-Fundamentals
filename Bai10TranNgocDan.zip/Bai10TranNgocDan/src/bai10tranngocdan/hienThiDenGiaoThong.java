/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai10tranngocdan;

/**
 *
 * @author hocvien
 */
public class hienThiDenGiaoThong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here0
        for(DenGiaoThong d: DenGiaoThong.values()){
            System.out.println("Den: "+d.name());
            System.out.println("So giay: "+d.getSoGiay());
            System.out.println("Tiep theo la den: "+d.chuyenDen()+"\n\n");
        }
    }

    enum DenGiaoThong {
        DO(30) {
            public DenGiaoThong chuyenDen() {
                return XANH;
            }
        },
        VANG(10) {
            public DenGiaoThong chuyenDen() {
                return DO;
            }
        },
        XANH(30) {
            public DenGiaoThong chuyenDen() {
                return VANG;
            }
        };

        private DenGiaoThong(int soGiay) {
            this.soGiay = soGiay;
        }

        public abstract DenGiaoThong chuyenDen();
        private int soGiay;

        public int getSoGiay() {
            return soGiay;
        }
    }
}
