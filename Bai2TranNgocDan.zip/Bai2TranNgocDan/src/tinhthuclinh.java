
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hocvien
 */
public class tinhthuclinh {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader (System.in));
        System.out.print("Nhap so san pham: ");
        int ssp = Integer.parseInt(input.readLine());
        System.out.print("Tien cong mot san pham: ");
        double tc = Double.parseDouble(input.readLine());
        System.out.print("Tien thuong: ");
        double tt = Double.parseDouble(input.readLine());
        System.out.print("So con: ");
        int sc = Integer.parseInt(input.readLine());
        
        double tl = ssp*tc;
        double pc = sc*200000;
        double thucLinh = tl + tt + pc;
        System.out.println("Tien luong: " + String.format("%.2f",tl));
        System.out.println("Phu cap: " + String.format("%.2f",pc));
        System.out.println("Thuc linh: " + String.format("%.2f",thucLinh));
    }
    
}
