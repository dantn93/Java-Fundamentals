
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hocvien
 */
public class tinhtienhang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader (System.in));
        System.out.print("Nhap so luong: ");
        int soLuong = Integer.parseInt(input.readLine());
        System.out.print("Nhap don gia: ");
        double donGia = Double.parseDouble(input.readLine());
        double thanhTien = soLuong * donGia;
        System.out.println("Thanh tien = " + String.format("%.2f",thanhTien));
        
    }
    
}
