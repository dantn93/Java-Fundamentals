
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hocvien
 */
public class tinhtienlaiguitietkiem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader (System.in));
        System.out.print("Nhap lai suat: ");
        double laiSuat = Double.parseDouble(input.readLine());
        System.out.print("Nhap so tien gui: ");
        double tienGui = Double.parseDouble(input.readLine());
        System.out.print("Nhap so thang gui: ");
        int thangGui = Integer.parseInt(input.readLine());
        double tienLai = tienGui*thangGui*(laiSuat/12);
        double tongTien = tienGui + tienLai;
        System.out.println("Tien lai: " + String.format("%.2f",tienLai));
        System.out.println("Tong von va lai: " + String.format("%.2f",tongTien));
    }
    
}
