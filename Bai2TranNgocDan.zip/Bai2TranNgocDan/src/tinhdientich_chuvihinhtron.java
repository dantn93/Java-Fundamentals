
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hocvien
 */
public class tinhdientich_chuvihinhtron {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader (System.in));
        System.out.print("Nhap ban kinh hinh tron: ");
        double bankinh = Double.parseDouble(input.readLine());
        double chuvi = 2*bankinh*3.14;
        double dtich = bankinh*bankinh*3.14;
        System.out.println("Chu vi = " + String.format("%.2f",chuvi));
        System.out.println("Dien tich = " + String.format("%.2f",dtich));
        
    }
    
}
