
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hocvien
 */
public class dientichhinhchunhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader (System.in));
        System.out.print("Nhap chu vi hinh chu nhat: ");
        double cv = Double.parseDouble(input.readLine());
        double r = cv/(2*2.5);
        double d = 1.5*r;
        double dt = d*r;
        System.out.println("Dien tich = " + String.format("%.2f",dt));
    }
    
}
