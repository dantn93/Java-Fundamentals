/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai3tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

public class tinhBieuthuc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhập x: ");
        float x = Float.parseFloat(input.readLine());
        double s = 1 + x + pow(x,3)/3 + pow(x,5)/5;
        System.out.println("S = 1 + x*x*x/3 + x*x*x*x*x/5 = " + String.format("%.2f", s));
 
    }
    
}
