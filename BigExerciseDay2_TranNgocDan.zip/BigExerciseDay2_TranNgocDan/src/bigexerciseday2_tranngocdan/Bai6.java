/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

/**
 *
 * @author hocvien
 */
public class Bai6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        inMaTran(mtA());
        inMaTran(mtB());
        inMaTran(mtC());
        inMaTran(mtD());
        mtG();
        System.out.println("");
        System.out.println("");
        inMaTran(mtE());
        System.out.println("");
        mtF();

    }
    
    public static void mtF() {
        int[][] mt = new int[8][8];
        int so = 8;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (j >= 8 - i) {
                    System.out.print(so+"");
                } else {
                    System.out.print(" ");
                }
                so--;
            }
            so = 8;
            System.out.println("");
        }
    }

    public static String[][] mtE() {
        String[][] mt = new String[8][8];
        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                mt[i][j] = " ";
            }
        }

        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                if (i == j) {
                    mt[i][j] = "1";
                }
                if (j == i + 1) {
                    mt[i][j] ="2";
                }
                if (j == i + 2) {
                    mt[i][j] ="3";
                }
                if (j == i + 3) {
                    mt[i][j] ="4";
                }
                if (j == i + 4) {
                    mt[i][j] ="5";
                }
                if (j == i + 5) {
                    mt[i][j] ="6";
                }
                if (j == i + 6) {
                    mt[i][j] ="7";
                }
                if (j == i + 7) {
                    mt[i][j] ="8";
                }
            }
        }
        return mt;
    }

    public static void mtG() {
        int[][] a = new int[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 8; j > 0; j--) {
                if (i + j <= 8) {
                    System.out.print(j + " ");
                }
            }
            System.out.println("");
        }
    }

    public static String[][] mtD() {
        String[][] mt = new String[8][8];
        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                mt[i][j] = " ";
            }
        }
        
        for (int i = 0; i < mt.length; i++) {
            for (int j = i; j < mt[i].length; j++) {
                mt[j][i] = ""+(i+1);
            }
        }
        
        return mt;
    }


//    }
    public static String[][] mtA() {
        String[][] mt = new String[11][11];
        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                mt[i][j] = " ";
            }
        }
        for (int i = 0; i < mt.length; i++) {
            for (int j = i; j < mt[i].length; j++) {
                if (j < mt[i].length - i) {
                    mt[i][j] = "#";
                }
            }
        }

        return mt;
    }

    public static String[][] mtB() {
        String[][] mt = new String[11][11];
        for (int i = 0; i < mt.length; i++) {
            for (int j = 0; j < mt[i].length; j++) {
                mt[i][j] = " ";
            }
        }

        for (int i = 0; i < mt.length / 2 + 1; i++) {
            for (int j = mt.length / 2 - i; j < mt.length / 2 + i + 1; j++) {
                mt[i][j] = "#";
            }
        }
        return mt;
    }

    public static String[][] mtC() {
        int k = 1;

        String[][] B = mtB();
        String[][] C = B.clone();
        String[][] A = mtA();
        for (int i = B.length / 2 + 1; i < B.length; i++) {
            int l = 0;
            for (int j = 0; j < B[i].length; j++) {
                C[i][j] = A[k][l];
                l++;
            }
            k++;
        }
        return C;
    }

    public static void inMaTran(String[][] matran) {
        for (int i = 0; i < matran.length; i++) {
            for (int j = 0; j < matran[i].length; j++) {
                System.out.print(matran[i][j] + " ");
            }
            System.out.println("");
        }
    }

}
