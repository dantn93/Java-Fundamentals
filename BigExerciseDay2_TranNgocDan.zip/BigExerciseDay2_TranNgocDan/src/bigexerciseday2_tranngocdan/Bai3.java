/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap n: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }

            System.out.print("Nhap m: ");
            int m = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (m <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    m = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //Tao mang ngau nhien
            int[][] matran = phatSinhNgauNhien(n, m);
            //==Nhap cot va sap xep
            System.out.print("Nhap k: ");
            int k = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (k < 0 || k >= m) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //== SAP XEP COT ===//
            inMaTran(matran);
            sapXepMang(matran, k);
            System.out.println("");
            inMaTran(matran);
            //Tinh tong dong chan, cot le
            int[] tong = tinhTongDongChanCotLe(matran);
            System.out.println("Tong dong chan: " + tong[0]);
            System.out.println("Tong cot le: " + tong[1]);

            //Thay so nguyen to
            thaySoNguyenTo(matran);
            System.out.println("");
            inMaTran(matran);
            //Tinh tong cac phan tu
            int[] kq = tinhCot_Hang_Dau_Cuoi(matran);
            System.out.println("Tong cac phan tu cot dau tien: " + kq[0]);
            System.out.println("Tong cac phan tu cot cuoi cung: " + kq[1]);
            System.out.println("Tong cac phan tu dong dau tien: " + kq[2]);
            System.out.println("Tong cac phan tu dong cuoi cung: " + kq[3]);
            
            //Kiem tra so chinh phuong
            inSoChinhPhuong(matran);
        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static int[] tinhCot_Hang_Dau_Cuoi(int[][] arr) {
        //Cot dau, cuoi
        //Dong dau, cuoi
        int[] kq = new int[4];
        for (int i = 0; i < kq.length; i++) {
            kq[i] = 0;
        }
        for (int i = 0; i < arr.length; i++) {
            kq[0] += arr[i][0];
            kq[1] += arr[i][arr[0].length - 1];

        }
        for (int i = 0; i < arr[0].length; i++) {
            kq[2] += arr[0][i];
            kq[3] += arr[arr.length - 1][i];
        }
        return kq;
    }

    public static void inSoChinhPhuong(int[][] arr) {
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] > 0) {
                    if (Math.sqrt(arr[i][j]) == (int) Math.sqrt(arr[i][j])) {
                        System.out.println("So chinh phuong ["+i+"]["+j+"] = "+arr[i][j]);
                        count = 1;
                    }
                }
            }
        }
        if(count == 1){
            System.out.println("Khong co so chinh phuong nao");
        }
    }

    public static int[][] phatSinhNgauNhien(int n, int m) {
        Random rd = new Random();
        int[][] arr = new int[n][m];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                arr[i][j] = rd.nextInt(m);
            }
        }
        return arr;
    }

    public static void sapXepMang(int[][] arr, int k) {
        System.out.println("Sap xep mang");
        int n = arr.length;
        int m = arr[0].length;
        for (int i = 0; i < arr.length - 1; i++) {
            System.out.println(i);
            for (int j = i + 1; j < arr[i].length - 1; j++) {
                if (arr[i][k] > arr[j][k]) {
                    int tam = arr[i][k];
                    arr[i][k] = arr[j][k];
                    arr[j][k] = tam;
                }
            }
        }
    }

    public static void inMaTran(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println("");
        }
    }

    public static int[] tinhTongDongChanCotLe(int[][] arr) {
        int[] kq = new int[2];
        kq[0] = 0;
        kq[1] = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (i % 2 == 0) {
                    kq[0] += arr[i][j];
                }
                if (j % 2 == 1) {
                    kq[1] += arr[i][j];
                }
            }
        }
        return kq;
    }

    public static void thaySoNguyenTo(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (ktSNT(arr[i][j])) {
                    arr[i][j] = -1;
                }
            }
        }
    }

    public static boolean ktSNT(int n) {
        int m = (int) Math.sqrt(n);
        if (n > 1) {
            for (int i = 2; i <= m; i++) {
                if (n % i == 0) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

}
