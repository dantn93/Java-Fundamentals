/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1 {

    /**
     * @param args the command line arguments
     */
    final static double HT1_KL_0 = 50;
    final static double HT1_EMS_NT_0 = 8000;
    final static double HT1_EMS_LT_V1_0 = 8500;
    final static double HT1_EMS_LT_V2_DN_0 = 9500;
    final static double HT1_EMS_LT_V2_HN_0 = 9500;
    final static double HT1_EMS_LT_V3_0 = 10000;

    final static double HT1_KL_1 = 100;
    final static double HT1_EMS_NT_1 = 8000;
    final static double HT1_EMS_LT_V1_1 = 12500;
    final static double HT1_EMS_LT_V2_DN_1 = 13500;
    final static double HT1_EMS_LT_V2_HN_1 = 13500;
    final static double HT1_EMS_LT_V3_1 = 14000;

    final static double HT1_KL_2 = 250;
    final static double HT1_EMS_NT_2 = 10000;
    final static double HT1_EMS_LT_V1_2 = 16500;
    final static double HT1_EMS_LT_V2_DN_2 = 20000;
    final static double HT1_EMS_LT_V2_HN_2 = 21500;
    final static double HT1_EMS_LT_V3_2 = 22500;

    final static double HT1_KL_3 = 500;
    final static double HT1_EMS_NT_3 = 12500;
    final static double HT1_EMS_LT_V1_3 = 23500;
    final static double HT1_EMS_LT_V2_DN_3 = 26500;
    final static double HT1_EMS_LT_V2_HN_3 = 28000;
    final static double HT1_EMS_LT_V3_3 = 29500;

    final static double HT1_KL_4 = 1000;
    final static double HT1_EMS_NT_4 = 15000;
    final static double HT1_EMS_LT_V1_4 = 33000;
    final static double HT1_EMS_LT_V2_DN_4 = 38500;
    final static double HT1_EMS_LT_V2_HN_4 = 40500;
    final static double HT1_EMS_LT_V3_4 = 43500;
    //5=========================================
    final static double HT1_KL_5 = 1500;
    final static double HT1_EMS_NT_5 = 18000;
    final static double HT1_EMS_LT_V1_5 = 40000;
    final static double HT1_EMS_LT_V2_DN_5 = 49500;
    final static double HT1_EMS_LT_V2_HN_5 = 52500;
    final static double HT1_EMS_LT_V3_5 = 55500;
    //6=======================
    final static double HT1_KL_6 = 2000;
    final static double HT1_EMS_NT_6 = 21000;
    final static double HT1_EMS_LT_V1_6 = 48500;
    final static double HT1_EMS_LT_V2_DN_6 = 59500;
    final static double HT1_EMS_LT_V2_HN_6 = 63500;
    final static double HT1_EMS_LT_V3_6 = 67500;
    //7=
    final static double HT1_KL_7 = 500;
    final static double HT1_EMS_NT_7 = 1600;
    final static double HT1_EMS_LT_V1_7 = 3800;
    final static double HT1_EMS_LT_V2_DN_7 = 8500;
    final static double HT1_EMS_LT_V2_HN_7 = 8500;
    final static double HT1_EMS_LT_V3_7 = 9500;

    //=== HINH THUC 2 ===//
    final static double HT2_KL_0 = 2000;
    final static double HT2_EMS_NT_0 = 50000;
    final static double HT2_EMS_LT_V1_0 = 70000;
    final static double HT2_EMS_LT_V2_DN_0 = 110000;
    final static double HT2_EMS_LT_V2_HN_0 = 130000;

    final static double HT2_KL_1 = 500;
    final static double HT2_EMS_NT_1 = 5000;
    final static double HT2_EMS_LT_V1_1 = 7000;
    final static double HT2_EMS_LT_V2_DN_1 = 12000;
    final static double HT2_EMS_LT_V2_HN_1 = 20000;

    //=== HINH THUC 3 ===//
    //1. Nac khoi luong
    final static double HT3_KL_0 = 2000;
    final static double HT3_EMS_NT_0 = 50000;
    final static double HT3_EMS_LT_V1_0 = 70000;
    final static double HT3_EMS_LT_V2_DN_0 = 85000;
    final static double HT3_EMS_LT_V2_HN_0 = 100000;
    final static double HT3_EMS_LT_V3_0 = 110000;

    final static double HT3_KL_1 = 500;
    final static double HT3_EMS_NT_1 = 5000;
    final static double HT3_EMS_LT_V1_1 = 7000;
    final static double HT3_EMS_LT_V2_DN_1 = 10000;
    final static double HT3_EMS_LT_V2_HN_1 = 12000;
    final static double HT3_EMS_LT_V3_1 = 15000;

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            //==Nhap trong luong buu pham
            System.out.println("===TRONG LUONG BUU PHAM===");
            System.out.print("Nhap trong luong buu pham: ");
            double tl = Double.parseDouble(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (tl <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    tl = Double.parseDouble(input.readLine());
                } else {
                    break;
                }
            }
            //==Nhap hinh thuc gui
            System.out.println("===HINH THUC GUI===");
            System.out.println("1. Hinh thuc 1: Cuoc EMS thuong");
            System.out.println("2. Hinh thuc 2: Cuoc dich vu phat trong ngay");
            System.out.println("3. Hinh thuc 3: Cuoc dich vu hoa toc");
            System.out.print("Chon: ");
            int ht = Integer.parseInt(input.readLine());
            while (true) {
                if (ht == 1 || ht == 2 || ht == 3) {
                    break;
                } else {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    ht = Integer.parseInt(input.readLine());
                }
            }

            //==Chon EMS la noi tinh hay lien tinh
            System.out.println("===chon LIEN TINH hay NOI TINH===");
            System.out.println("1. Noi tinh");
            System.out.println("2. Lien tinh");
            System.out.print("Chon: ");
            int lt_nt = Integer.parseInt(input.readLine());
            while (true) {
                if (lt_nt == 1 || lt_nt == 2) {
                    break;
                } else {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    ht = Integer.parseInt(input.readLine());
                }
            }
            //==Chon Vung (LIEN TINH)
            int vung = 0;
            int vungNho = 0;
            if (lt_nt == 2) {
                System.out.println("===chon VUNG===");
                System.out.println("1. Vung 1");
                System.out.println("2. Vung 2");
                if (ht == 1 || ht == 3) {
                    System.out.println("3. Vung 3");
                }
                System.out.print("Chon: ");
                vung = Integer.parseInt(input.readLine());
                while (true) {
                    if (ht == 2 && (vung == 1 || vung == 2)) {
                        break;
                    } else if ((vung == 1 || vung == 2 || vung == 3) && (ht == 1 || ht == 3)) {
                        break;
                    } else {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        vung = Integer.parseInt(input.readLine());
                    }
                }
                if (vung == 2) {
                    //==Chon vung nho hon trong Vung 2
                    System.out.println("===chon Vung trong VUNG 2===");
                    System.out.println("1. Da Nang di HN, HCM va nguoc lai");
                    System.out.println("2. HN di HCM va nguoc lai");
                    System.out.print("Chon: ");
                    vungNho = Integer.parseInt(input.readLine());
                    System.out.println("Vung nho: " + vungNho);
                    while (true) {
                        if (vungNho == 2 || vungNho == 1) {
                            break;
                        } else {
                            System.out.print("Nhap sai! Hay nhap lai: ");
                            vungNho = Integer.parseInt(input.readLine());
                        }
                    }
                }

            }
            //==TINH TOAN==//
            System.out.println("Cuoc phi: " + tinhCuoc(tl, ht, lt_nt, vung, vungNho));

        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }

    }

    public static double tinhCuoc(double kl, int ht, int nt_lt, int vung, int vungNho) {
        System.out.println("Vung nho:" + vungNho);
        double phi = 0;
        switch (ht) {
            //Hinh thuc 1
            case 1:
                //khoi luong <= 50
                if (kl > 0 && kl <= HT1_KL_0) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 100
                if (kl > HT1_KL_0 && kl <= HT1_KL_1) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_1;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 250
                if (kl > HT1_KL_1 && kl <= HT1_KL_2) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 500
                if (kl > HT1_KL_2 && kl <= HT1_KL_3) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_3 + HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_3 + HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_3 + HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_3 + HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_3 + HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 1000
                if (kl > HT1_KL_3 && kl <= HT1_KL_4) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_4 + HT1_EMS_NT_3 + HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_4 + HT1_EMS_LT_V1_3 + HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_4 + HT1_EMS_LT_V2_DN_3 + HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_4 + HT1_EMS_LT_V2_HN_3 + HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_4 + HT1_EMS_LT_V3_3 + HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 1500
                if (kl > HT1_KL_4 && kl <= HT1_KL_5) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_5 + HT1_EMS_NT_4 + HT1_EMS_NT_3 + HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_5 + HT1_EMS_LT_V1_4 + HT1_EMS_LT_V1_3 + HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_5 + HT1_EMS_LT_V2_DN_4 + HT1_EMS_LT_V2_DN_3 + HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_5 + HT1_EMS_LT_V2_HN_4 + HT1_EMS_LT_V2_HN_3 + HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_5 + HT1_EMS_LT_V3_4 + HT1_EMS_LT_V3_3 + HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong <= 2000
                if (kl > HT1_KL_5 && kl <= HT1_KL_6) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT1_EMS_NT_6 + HT1_EMS_NT_5 + HT1_EMS_NT_4 + HT1_EMS_NT_3 + HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_6 + HT1_EMS_LT_V1_5 + HT1_EMS_LT_V1_4 + HT1_EMS_LT_V1_3 + HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_6 + HT1_EMS_LT_V2_DN_5 + HT1_EMS_LT_V2_DN_4 + HT1_EMS_LT_V2_DN_3 + HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_6 + HT1_EMS_LT_V2_HN_5 + HT1_EMS_LT_V2_HN_4 + HT1_EMS_LT_V2_HN_3 + HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_6 + HT1_EMS_LT_V3_5 + HT1_EMS_LT_V3_4 + HT1_EMS_LT_V3_3 + HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong tren 2000 moi nac 500
                if (kl > HT1_KL_6) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        double sodu = Math.ceil((kl - HT1_KL_6) / HT1_KL_7);
                        phi = HT1_EMS_NT_6 + HT1_EMS_NT_5 + HT1_EMS_NT_4 + HT1_EMS_NT_3 + HT1_EMS_NT_2 + HT1_EMS_NT_1 + HT1_EMS_NT_0 + sodu * HT1_EMS_NT_7;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        double sodu = Math.ceil((kl - HT1_KL_6) / HT1_KL_7);
                        if (vung == 1) {
                            phi = HT1_EMS_LT_V1_6 + HT1_EMS_LT_V1_5 + HT1_EMS_LT_V1_4 + HT1_EMS_LT_V1_3 + HT1_EMS_LT_V1_2 + HT1_EMS_LT_V1_1 + HT1_EMS_LT_V1_0 + sodu * HT1_EMS_LT_V1_7;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT1_EMS_LT_V2_DN_6 + HT1_EMS_LT_V2_DN_5 + HT1_EMS_LT_V2_DN_4 + HT1_EMS_LT_V2_DN_3 + HT1_EMS_LT_V2_DN_2 + HT1_EMS_LT_V2_DN_1 + HT1_EMS_LT_V2_DN_0 + sodu * HT1_EMS_LT_V2_DN_7;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_6 + HT1_EMS_LT_V2_HN_5 + HT1_EMS_LT_V2_HN_4 + HT1_EMS_LT_V2_HN_3 + HT1_EMS_LT_V2_HN_2 + HT1_EMS_LT_V2_HN_1 + HT1_EMS_LT_V2_HN_0 + sodu * HT1_EMS_LT_V2_HN_7;
                        }
                        if (vung == 3) {
                            phi = HT1_EMS_LT_V3_6 + HT1_EMS_LT_V3_5 + HT1_EMS_LT_V3_4 + HT1_EMS_LT_V3_3 + HT1_EMS_LT_V3_2 + HT1_EMS_LT_V3_1 + HT1_EMS_LT_V3_0 + sodu * HT1_EMS_LT_V3_7;
                        }
                    }
                }
                break;
            case 2:
                //khoi luong <= 2000
                if (kl > 0 && kl <= HT2_KL_0) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT2_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT2_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT2_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT2_EMS_LT_V2_HN_0;
                        }
                    }
                }
                //Khoi luong tren 2000 moi nac 500
                if (kl > HT2_KL_0) {
                    //Noi tinh
                    double sodu = Math.ceil((kl - HT2_KL_0) / HT2_KL_1);
                    if (nt_lt == 1) {
                        phi = HT2_EMS_NT_0 + sodu * HT2_EMS_NT_1;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT2_EMS_LT_V1_0 + sodu * HT1_EMS_LT_V1_1;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT2_EMS_LT_V2_DN_0 + sodu * HT2_EMS_LT_V2_DN_1;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT1_EMS_LT_V2_HN_0 + sodu * HT1_EMS_LT_V2_HN_1;
                        }
                    }
                }
                break;
            case 3:
                //khoi luong <= 2000
                if (kl > 0 && kl <= HT3_KL_0) {
                    //Noi tinh
                    if (nt_lt == 1) {
                        phi = HT3_EMS_NT_0;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT3_EMS_LT_V1_0;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT3_EMS_LT_V2_DN_0;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT3_EMS_LT_V2_HN_0;
                        }
                        if (vung == 3) {
                            phi = HT3_EMS_LT_V3_0;
                        }
                    }
                }
                //Khoi luong tren 2000 moi nac 500
                if (kl > HT3_KL_0) {
                    //Noi tinh
                    double sodu = Math.ceil((kl - HT3_KL_0) / HT3_KL_1);
                    if (nt_lt == 1) {

                        phi = HT1_EMS_NT_0 + sodu * HT1_EMS_NT_1;
                    }
                    //Lien tinh
                    if (nt_lt == 2) {
                        if (vung == 1) {
                            phi = HT3_EMS_LT_V1_0 + sodu * HT3_EMS_LT_V1_1;
                        }
                        if (vung == 2 && vungNho == 1) {
                            phi = HT3_EMS_LT_V2_DN_0 + sodu * HT3_EMS_LT_V2_DN_1;
                        }
                        if (vung == 2 && vungNho == 2) {
                            phi = HT3_EMS_LT_V2_HN_0 + sodu * HT3_EMS_LT_V2_HN_1;
                        }
                        if (vung == 3) {
                            phi = HT3_EMS_LT_V3_0 + sodu * HT1_EMS_LT_V3_1;
                        }
                    }
                }
        }

        return phi;
    }

}
