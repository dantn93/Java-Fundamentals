/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

            String[] mangTu = new String[]{"program",
                "developer", "testing", "coder", "algorithm", "bug",
                "console", "user", "system", "application"};
            System.out.println("Trong bo nay co: " + mangTu.length + " tu");
            System.out.print("Ban muon doan o vi tri so may: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n < 0 || n >= mangTu.length) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }

            System.out.println("Chieu dai cua tu vua cho co: " + mangTu[n].length() + " phan tu");
            String[] mang = new String[mangTu[n].length()];
            for (int i = 0; i < mang.length; i++) {
                mang[i] = "*";
            }
            int soLan = 0;
            int diem = 0;
            boolean doanThanhCong = false;
            boolean hetDoan = false;
            while (true) {
                String chon = "";
                soLan++;
                if (soLan >= 2) {
                    System.out.print("Ban co muon doan luon ca tu hay khong (y/n): ");
                    while (true) {
                        chon = input.readLine();
                        if (chon.equalsIgnoreCase("y") || chon.equalsIgnoreCase("n")) {
                            break;
                        } else {
                            System.out.print("Chon: ");
                        }
                    }
                }
                if (chon.equalsIgnoreCase("y")) {
                    System.out.print("Lan " + soLan + " Doan ca tu: ");
                    String doanHet = input.readLine();
                    if (doanHet.equalsIgnoreCase(mangTu[n])) {
                        doanThanhCong = true;
                        break;
                    }
                } else if (chon.equalsIgnoreCase("n")) {

                    System.out.print("Ban doan trong tu co ky tu: ");
                    String doan = input.readLine();
                    int d = 0;
                    for (int i = 0; i < mangTu[n].length(); i++) {

                        if (doan.equalsIgnoreCase(mangTu[n].charAt(i) + "")) {
                            d++;
                            mang[i] = doan;
                        }

                    }
                    if (d > 0) {
                        System.out.print("Lan " + soLan + ": Chuc mung ban. Co " + d + " ky tu " + doan + ": ");
                        for (int i = 0; i < mang.length; i++) {
                            System.out.print(mang[i]);
                        }
                        diem++;
                    }else
                        System.out.println("Trong tu khong co ky tu nay");
                    System.out.println("");
                }
                int dm = 0;
                for(int i=0;i<mang.length;i++){
                    if(!mang[i].equals("*"))
                        dm++;
                }
                if(dm == mang.length)
                {
                    doanThanhCong =  true;
                    break;
                }
            }
            if(doanThanhCong){
                System.out.println("Chuc mung ban da nhanh chong tim ra chinh xac tu nay");
            }
            else
                System.out.println("Sorry ban, ban da doan sai va mat quyen choi tiep tro choi nay");

        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

}
