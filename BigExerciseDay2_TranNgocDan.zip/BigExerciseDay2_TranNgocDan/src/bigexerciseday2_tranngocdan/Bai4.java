/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap so sinh vien: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            double[] diem = new double[n];
            System.out.println("Nhap diem tung sinh vien");
            for (int i = 0; i < n; i++) {
                System.out.print("Sinh vien "+i+": ");
                diem[i] = Double.parseDouble(input.readLine());
                //===Kiem tra nhap dung===//
                while (true) {
                    if (diem[i] < 0 || diem[i]>10) {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        diem[i] = Double.parseDouble(input.readLine());
                    } else {
                        break;
                    }
                }
            }
            //In diem trung binh
            System.out.println("Diem trung binh: "+tinhDiemTB(diem));
            //Diem lon nhat, be nhat
            double[] kq = timDiemLN_NN(diem);
            System.out.println("Diem lon nhat: "+kq[0]);
            System.out.println("Diem be nhat: "+kq[1]);
        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }
    
    public static double tinhDiemTB(double[] arr){
        double sum = 0;
        for(int i=0;i<arr.length;i++){
            sum+=arr[i];
        }
        return (sum/arr.length);
    }
    public static double[] timDiemLN_NN(double[] arr){
        double[] kq = new double[2];
        kq[0] = arr[0];
        kq[1] = arr[0];
        for(int i=1;i<arr.length;i++){
            if(kq[0] < arr[i])
                kq[0] = arr[i];
            if(kq[1] > arr[i])
                kq[1] = arr[i];
        }
        return kq;
    }

}
