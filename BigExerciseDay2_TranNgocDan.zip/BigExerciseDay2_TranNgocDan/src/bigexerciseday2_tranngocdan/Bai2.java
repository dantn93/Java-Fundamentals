/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2 {

    /**
     * @param args the command line arguments
     */
    enum KHONGSINHHOAT {
        SANXUAT(9600, 480, 960, 11040), DOANTHE(10300, 515, 1030, 11845), KINHDOANH(169000, 845, 1690, 19435);
        private double gianuoc;
        private double thueGTGT;
        private double baoVe;
        private double cong;

        private KHONGSINHHOAT(double r1, double r2, double r3, double r4) {
            this.gianuoc = r1;
            this.thueGTGT = r2;
            this.baoVe = r3;
            this.cong = r4;
        }

        public double layGiaNuoc() {
            return this.gianuoc;
        }

        public double layThueGTGT() {
            return this.thueGTGT;
        }

        public double layPhiBaoVe() {
            return this.baoVe;
        }

        public double layTong() {
            return this.cong;
        }

    }

    enum SINHHOAT {
        DEN4(5300, 265, 530, 6095), DEN6(10200, 510, 1020, 11730), TREN6(11400, 570, 1140, 13110);
        private double gianuoc;
        private double thueGTGT;
        private double baoVe;
        private double cong;
        private int soNguoi;
        private double theTich;

        private SINHHOAT(double r1, double r2, double r3, double r4) {
            this.gianuoc = r1;
            this.thueGTGT = r2;
            this.baoVe = r3;
            this.cong = r4;
            this.theTich = 0;
        }

        public double layGiaNuoc() {
            return this.gianuoc;
        }

        public double layThueGTGT() {
            return this.thueGTGT;
        }

        public double layPhiBaoVe() {
            return this.baoVe;
        }

        public double layTong() {
            return this.cong;
        }

        public double tinhTienNuocKhongThue_Phi(double theTich, int soNguoi) {
            return this.gianuoc * soNguoi * theTich;
        }

        public double tienThueGTGT(double theTich, int soNguoi) {
            return this.thueGTGT * soNguoi * theTich;
        }

        public double tienPhiBaoVe(double theTich, int soNguoi) {
            return this.baoVe * soNguoi * theTich;
        }

        public double tongTien(double theTich, int soNguoi) {
            return this.cong * soNguoi * theTich;
        }
    }

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            //==Nhap trong luong buu pham
            System.out.print("Nhap so m3 nuoc da dung trong thang: ");
            double thetich = Double.parseDouble(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (thetich < 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    thetich = Double.parseDouble(input.readLine());
                } else {
                    break;
                }
            }
            System.out.println("===Chon doi tuong sinh hoat===");
            System.out.println("1. Sinh hoat");
            System.out.println("2. Khong sinh hoat");
            System.out.print("Chon: ");
            int doiTuong = Integer.parseInt(input.readLine());
            while (true) {
                if (doiTuong == 1 || doiTuong == 2) {
                    break;
                } else {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    doiTuong = Integer.parseInt(input.readLine());
                }
            }
            int soNguoi = 0;
            if (doiTuong == 1) {
                System.out.print("Nhap so nguoi trong ho gia dinh: ");
                soNguoi = Integer.parseInt(input.readLine());
                while (true) {
                    if (soNguoi > 0) {
                        break;
                    } else {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        soNguoi = Integer.parseInt(input.readLine());
                    }
                }
            }
            int loai = 0;
            if (doiTuong == 2) {
                System.out.println("===Chon loai===");
                System.out.println("1. Don vi san xuat");
                System.out.println("2. Co quan, doan the, HC su nghiep");
                System.out.println("3. Don vi kinh doanh, dich vu");
                loai = Integer.parseInt(input.readLine());
                while (true) {
                    if (loai == 1 || loai == 2 || loai == 3) {
                        break;
                    } else {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        loai = Integer.parseInt(input.readLine());
                    }
                }
            }
            //===Tinh Toan===//
            System.out.println("Tong so m3: " + thetich);
            if (doiTuong == 1) {
                System.out.println("Tien nuoc khong tinh thue: "+tinhPhiSINHHOAT(thetich,soNguoi)[0]);
                System.out.println("Tien thue GTGT: "+tinhPhiSINHHOAT(thetich,soNguoi)[1]);
                System.out.println("Tien phi bao ve moi truong: "+tinhPhiSINHHOAT(thetich,soNguoi)[2]);
                System.out.println("So tien cuoi cung phai tra: "+tinhPhiSINHHOAT(thetich,soNguoi)[3]);
            }
            if(doiTuong == 2){
                System.out.println("Tien nuoc khong tinh thue: "+tinhPhikhongSINHHOAT(thetich,soNguoi)[0]);
                System.out.println("Tien thue GTGT: "+tinhPhikhongSINHHOAT(thetich,soNguoi)[1]);
                System.out.println("Tien phi bao ve moi truong: "+tinhPhikhongSINHHOAT(thetich,soNguoi)[2]);
                System.out.println("So tien cuoi cung phai tra: "+tinhPhikhongSINHHOAT(thetich,soNguoi)[3]);
            }

        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static double[] tinhPhiSINHHOAT(double tt, int songuoi) {
        double[] phi = new double[4];
        double theTich = tt / songuoi;
        if (theTich >= 0 && theTich <= 4) {
            phi[0] = SINHHOAT.DEN4.tinhTienNuocKhongThue_Phi(theTich, songuoi);
            phi[1] = SINHHOAT.DEN4.tienThueGTGT(theTich, songuoi);
            phi[2] = SINHHOAT.DEN4.tienPhiBaoVe(theTich, songuoi);
            phi[3] = SINHHOAT.DEN4.tongTien(theTich, songuoi);
        }
        if (theTich > 4 && theTich <= 6) {
            phi[0] = SINHHOAT.DEN6.tinhTienNuocKhongThue_Phi(theTich - 4, songuoi)+SINHHOAT.DEN4.tinhTienNuocKhongThue_Phi(4, songuoi);
            phi[1] = SINHHOAT.DEN6.tienThueGTGT(theTich - 4, songuoi);
            phi[2] = SINHHOAT.DEN6.tienPhiBaoVe(theTich - 4, songuoi);
            phi[3] = SINHHOAT.DEN6.tongTien(theTich - 4, songuoi);
        }
        if (theTich > 6) {
            phi[0] = SINHHOAT.TREN6.tinhTienNuocKhongThue_Phi(theTich - 6, songuoi)+SINHHOAT.DEN6.tinhTienNuocKhongThue_Phi(2, songuoi)+SINHHOAT.DEN4.tinhTienNuocKhongThue_Phi(4, songuoi);
            phi[1] = SINHHOAT.TREN6.tienThueGTGT(theTich - 6, songuoi)+SINHHOAT.DEN6.tienThueGTGT(2, songuoi)+SINHHOAT.DEN4.tienThueGTGT(4, songuoi);
            phi[2] = SINHHOAT.TREN6.tienPhiBaoVe(theTich - 6, songuoi)+SINHHOAT.DEN6.tienPhiBaoVe(2, songuoi)+SINHHOAT.DEN4.tienPhiBaoVe(4, songuoi);
            phi[3] = SINHHOAT.TREN6.tongTien(theTich - 6, songuoi)+SINHHOAT.DEN6.tongTien(2, songuoi)+SINHHOAT.DEN4.tongTien(4, songuoi);
        }
        return phi;
    }

    public static double[] tinhPhikhongSINHHOAT(double tt, int loai) {
        double[] phi = new double[4];
        if (loai == 1) {
            phi[0] = KHONGSINHHOAT.SANXUAT.layGiaNuoc() * tt;
            phi[1] = KHONGSINHHOAT.SANXUAT.layThueGTGT() * tt;
            phi[2] = KHONGSINHHOAT.SANXUAT.layPhiBaoVe() * tt;
            phi[3] = KHONGSINHHOAT.SANXUAT.layTong() * tt;
        }
        if (loai == 2) {
            phi[0] = KHONGSINHHOAT.DOANTHE.layGiaNuoc() * tt;
            phi[1] = KHONGSINHHOAT.DOANTHE.layThueGTGT() * tt;
            phi[2] = KHONGSINHHOAT.DOANTHE.layPhiBaoVe() * tt;
            phi[3] = KHONGSINHHOAT.DOANTHE.layTong() * tt;
        }
        if (loai == 3) {
            phi[0] = KHONGSINHHOAT.KINHDOANH.layGiaNuoc() * tt;
            phi[1] = KHONGSINHHOAT.KINHDOANH.layThueGTGT() * tt;
            phi[2] = KHONGSINHHOAT.KINHDOANH.layPhiBaoVe() * tt;
            phi[3] = KHONGSINHHOAT.KINHDOANH.layTong() * tt;
        }
        return phi;
    }

}
