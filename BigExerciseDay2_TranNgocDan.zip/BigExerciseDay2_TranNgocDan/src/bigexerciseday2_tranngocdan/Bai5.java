/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bigexerciseday2_tranngocdan;

/**
 *
 * @author hocvien
 */
public class Bai5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[][] matran = new String[8][8];
        System.out.println("---------------------------------");
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (i % 2 == 0 && j % 2 == 0) {
                    matran[i][j] = "W";
                } 
                else{
                    matran[i][j] = "B";
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            System.out.print("| ");
            for (int j = 0; j < 8; j++) {
                System.out.print(matran[i][j]+" | ");
            }
            
            System.out.println("\n---------------------------------");
        }
    }

}
