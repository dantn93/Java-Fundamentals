/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class Bai52_tinhA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.print("Nhap x: ");
        float x = Float.parseFloat(input.readLine());
        float A1 = 1;
        float A2 = 1;
        for (int i = 0; i < n; i++) {
            A1 *= (x * x + x + 1);
            A2 *= (x * x - x + 1);
        }
        System.out.println("Viet thuong A = (x * x + x + 1) mu " + n + " (x * x - x + 1) mu " + n + " = " + String.format("%.2f", A1 + A2));
    
        //Viet function
        double A = tinhA(x,n);
        System.out.println("Viet Function A = (x * x + x + 1) mu " + n + " (x * x - x + 1) mu " + n + " = " + String.format("%.2f", A));
    }

    public static double tinhA(double x, int n) {
        float A1 = 1;
        float A2 = 1;
        int m = n;
        
        if(n < 0)
            m = -n;
        for (int i = 0; i < m; i++) {
            A1 *= (x * x + x + 1);
            A2 *= (x * x - x + 1);
        }
        if(n < 0)
            return (double)1/(double)A1 + (double)1/(double)A2;
        return A1+A2;
    }
}
