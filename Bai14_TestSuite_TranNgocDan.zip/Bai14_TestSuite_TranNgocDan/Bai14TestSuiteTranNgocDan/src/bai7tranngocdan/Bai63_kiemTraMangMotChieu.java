/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Collections;
import static java.util.Collections.list;

/**
 *
 * @author hocvien
 */
public class Bai63_kiemTraMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    public static void xuatMang(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
    public static int[] nhapMang(int n) throws IOException
    {
        System.out.println("Nhap gia tri cho cac phan tu trong mang: ");
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Phan tu thu " + i + ": ");
            arr[i] = Integer.parseInt(input.readLine());
        }
        return arr;
    }
    public static boolean kiemTraMangTang(int[] arr)
    {
        int n = arr.length;
        int[] temp = new int[n];
        System.arraycopy(arr, 0, temp, 0, n);
        Arrays.parallelSort(temp);
        if (Arrays.equals(arr, temp)) {
            System.out.println("Mang a sap tang dan");
            return true;
        }
        return false;
    }
    public static boolean kiemTraMangGiam(int[] arr){
        int count = 0;
        for(int i=0;i<arr.length-1;i++)
        {
            if(arr[i] >= arr[i+1])
                count++;
        }
        if(count == arr.length-1){
            System.out.println("Mang a sap giam dan");
            return true;
        }
        return false;
    }
    public static int kiemTraTanCung6(int[] arr){
        for(int i=0;i<arr.length;i++)
        {
            if(arr[i] % 10 == 6)
            {
                System.out.println("Phan tu dau tien co tan cung la 6: "+arr[i]);
                return arr[i];
            }
        }
        return -1;
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = nhapMang(n);
        
        //Xuat mang a
        xuatMang(arr);
        //Kiem tra mang tang dan
        kiemTraMangTang(arr);
        //Kiem tra mang giam dan
        kiemTraMangGiam(arr);
        //Tim va in ra phan tu dau tien trong mang co tan cung la 6
        kiemTraTanCung6(arr);
    }
}
