/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class Bai51_tinhS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.print("Nhap x: ");
        float x = Float.parseFloat(input.readLine());
        if (n > 0) {
            float S = 1;
            for (int i = 0; i < n; i++) {
                S *= (x * x + 1);
            }
            System.out.println("Viet thong thuong S = (x * x + 1) mu " + n + " = " + String.format("%.2f", S));
        } else if (n == 0) {
            System.out.println("Viet thong thuong S = 1");
        }

        double S = tinhS(x, n);
        System.out.println("Viet function S = (x * x + 1) mu " + n + " = " + S);
    }

    public static double tinhS(double x, int n) {
        int m = n;
        if (n < 0) {
            m = -n;
        }
        float S = 1;
        if (m > 0) {
            for (int i = 0; i < m; i++) {
                S *= (x * x + 1);
            }
            if (n > 0) {
                return S;
            } else {
                return (double) 1 / (double) S;
            }
        } else if (n == 0) {
            return 1;
        }
        return S;
    }

}
