/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai56_doi10to2;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class doi10_2 {
    
    public doi10_2() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void doi10_2() {
        String ex = "0";
        String ac = Bai56_doi10to2.doi10_2(0);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_21() {
        String ex = "100";
        String ac = Bai56_doi10to2.doi10_2(4);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_22() {
        String ex = "110";
        String ac = Bai56_doi10to2.doi10_2(6);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_23() {
        String ex = "1";
        String ac = Bai56_doi10to2.doi10_2(1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_24() {
        String ex = "111";
        String ac = Bai56_doi10to2.doi10_2(7);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_25() {
        String ex = "11";
        String ac = Bai56_doi10to2.doi10_2(0);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_26() {
        String ex = "10";
        String ac = Bai56_doi10to2.doi10_2(4);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_27() {
        String ex = "111111";
        String ac = Bai56_doi10to2.doi10_2(6);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_28() {
        String ex = "1010";
        String ac = Bai56_doi10to2.doi10_2(1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi10_29() {
        String ex = "1";
        String ac = Bai56_doi10to2.doi10_2(7);
        assertEquals(ex, ac);
    }
}
