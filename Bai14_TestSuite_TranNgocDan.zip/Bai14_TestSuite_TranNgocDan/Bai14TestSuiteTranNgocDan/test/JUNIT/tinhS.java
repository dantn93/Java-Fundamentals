package JUNIT;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import bai7tranngocdan.Bai51_tinhS;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhS {

    public tinhS() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhS() {
        double ex = 1;
        double ac = Bai51_tinhS.tinhS(0, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS1() {
        double ex = 0.25;
        double ac = Bai51_tinhS.tinhS(1, -2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS2() {
        double ex = 125;
        double ac = Bai51_tinhS.tinhS(2, 3);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS3() {
        double ex = 26;
        double ac = Bai51_tinhS.tinhS(-5, 1);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS4() {
        double ex = 1;
        double ac = Bai51_tinhS.tinhS(-1, 0);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS5() {
        double ex = 4;
        double ac = Bai51_tinhS.tinhS(0, -1);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS6() {
        double ex = 6;
        double ac = Bai51_tinhS.tinhS(1, 2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS7() {
        double ex = 2;
        double ac = Bai51_tinhS.tinhS(-1, -2);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhS8() {
        double ex = 5;
        double ac = Bai51_tinhS.tinhS(2, 7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhS9() {
        double ex = 7;
        double ac = Bai51_tinhS.tinhS(-3, 10);
        assertEquals(ex, ac, 0.01);
    }
}
