/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai74_tinhNamAmLich;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhChi {
    
    public tinhChi() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    //===Tinh chi
    @Test
    public void tinhChi() {
        String ex = "Thin";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }

    @Test
    public void tinhChi1() {
        String ex = "Dau";
        String ac = Bai74_tinhNamAmLich.tinhChi(1993);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi2() {
        String ex = "Ty";
        String ac = Bai74_tinhNamAmLich.tinhChi(2001);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi3() {
        String ex = "Mui";
        String ac = Bai74_tinhNamAmLich.tinhChi(2003);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi4() {
        String ex = "Ngo";
        String ac = Bai74_tinhNamAmLich.tinhChi(2002);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi5() {
        String ex = "Than";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi6() {
        String ex = "Dau";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi7() {
        String ex = "Ngo";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi8() {
        String ex = "Mui";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhChi9() {
        String ex = "Than";
        String ac = Bai74_tinhNamAmLich.tinhChi(2000);
        assertEquals(ex, ac);
    }
}
