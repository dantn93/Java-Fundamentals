/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai65_xuLyMangHaiChieu;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class phanTuLN_NN {
    
    public phanTuLN_NN() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    //=== Phan tu lon nhat, nho nhat === //
    @Test
    public void phanTuLN_NN() {
        int[] ex = new int[]{6,1};
        int[][] arr = new int[][]{{1,2,3,5},{2,4,5,6}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN1() {
        int[] ex = new int[]{0,0};
        int[][] arr = new int[][]{{0,0,0},{0,0,0}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN2() {
        int[] ex = new int[]{2,2};
        int[][] arr = new int[][]{{2,2},{2,2}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN3() {
        int[] ex = new int[]{1,1};
        int[][] arr = new int[][]{{1,1,1},{1,1,1}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN4() {
        int[] ex = new int[]{3,-2};
        int[][] arr = new int[][]{{-1,2,3},{-2,2,3}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN5() {
        int[] ex = new int[]{8,1};
        int[][] arr = new int[][]{{5,6,7,8},{2,3,4,5}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN6() {
        int[] ex = new int[]{8,2};
        int[][] arr = new int[][]{{6,7,8},{3,4,5}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN7() {
        int[] ex = new int[]{1,0};
        int[][] arr = new int[][]{{1,3,5,7,9},{0,2,4,6,8}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN8() {
        int[] ex = new int[]{0,1};
        int[][] arr = new int[][]{{5,6,7,8,9},{1,2,3,4,5}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    @Test
    public void phanTuLN_NN9() {
        int[] ex = new int[]{0,2};
        int[][] arr = new int[][]{{0,0,0,0},{1,1,1,1}};
        int[] ac = Bai65_xuLyMangHaiChieu.phanTuLN_NN(arr);
        assertArrayEquals(ex, ac);
    }
    
    
}
