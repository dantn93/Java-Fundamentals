/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;


import bai7tranngocdan.Bai54_tinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhC {
    
    public tinhC() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhC() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhC(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC1() {
        double ex = 24;
        double ac = Bai54_tinhGTBT.tinhC(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC2() {
        double ex = 720;
        double ac = Bai54_tinhGTBT.tinhC(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC3() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhC(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC4() {
        double ex = 5040;
        double ac = Bai54_tinhGTBT.tinhC(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC5() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhC(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC6() {
        double ex = 31;
        double ac = Bai54_tinhGTBT.tinhC(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC7() {
        double ex = 721;
        double ac = Bai54_tinhGTBT.tinhC(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC8() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhC(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhC9() {
        double ex = 14;
        double ac = Bai54_tinhGTBT.tinhC(7);
        assertEquals(ex, ac, 0.01);
    }
}
