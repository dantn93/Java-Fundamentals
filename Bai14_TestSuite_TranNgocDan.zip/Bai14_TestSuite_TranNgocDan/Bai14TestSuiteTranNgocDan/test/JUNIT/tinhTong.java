/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai61_xuLyMangNgauNhien;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhTong {
    
    public tinhTong() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void ktTong() {
        int ex = 28;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(1,2,3,4,5,6,7);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong1() {
        int ex = 28;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(1,2,3,4,5,6,7);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong2() {
        int ex = 0;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(0,0,0,0,0,0);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong3() {
        int ex = 21;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(3,3,3,3,3,3,3);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong4() {
        int ex = 2;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(2);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong5() {
        int ex = 1;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(-1,1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong6() {
        int ex = 3;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(1,0,1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong7() {
        int ex = 1;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(-2,-2,-2,2,2,2);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong8() {
        int ex = 0;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(0,1);
        assertEquals(ex, ac);
    }
    
    @Test
    public void ktTong9() {
        int ex = 5;
        int ac = Bai61_xuLyMangNgauNhien.tinhTong(-2,2);
        assertEquals(ex, ac);
    }

}

