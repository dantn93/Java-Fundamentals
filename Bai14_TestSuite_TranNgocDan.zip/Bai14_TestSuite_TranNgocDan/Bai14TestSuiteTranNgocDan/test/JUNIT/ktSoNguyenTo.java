/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai53_ktSoNT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class ktSoNguyenTo {
    
    public ktSoNguyenTo() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void ktSNT() {
        boolean ac = Bai53_ktSoNT.ktSNT(3);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT1() {
        boolean ac = Bai53_ktSoNT.ktSNT(2);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT2() {
        boolean ac = Bai53_ktSoNT.ktSNT(5);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT3() {
        boolean ac = Bai53_ktSoNT.ktSNT(7);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT4() {
        boolean ac = Bai53_ktSoNT.ktSNT(13);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT5() {
        boolean ac = Bai53_ktSoNT.ktSNT(0);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT6() {
        boolean ac = Bai53_ktSoNT.ktSNT(1);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT7() {
        boolean ac = Bai53_ktSoNT.ktSNT(-6);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT8() {
        boolean ac = Bai53_ktSoNT.ktSNT(14);
        assertTrue(ac);
    }
    
    @Test
    public void ktSNT9() {
        boolean ac = Bai53_ktSoNT.ktSNT(-3);
        assertTrue(ac);
    }
}
