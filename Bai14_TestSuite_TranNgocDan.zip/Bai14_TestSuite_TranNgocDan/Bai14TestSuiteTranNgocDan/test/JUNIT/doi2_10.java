/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai57_doi2to10;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class doi2_10 {
    
    public doi2_10() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void doi2_10() {
        int ex = 0;
        int ac = Bai57_doi2to10.doi2_10("0");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_101() {
        int ex = 4;
        int ac = Bai57_doi2to10.doi2_10("100");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_102() {
        int ex = 6;
        int ac = Bai57_doi2to10.doi2_10("110");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_103() {
        int ex = 1;
        int ac = Bai57_doi2to10.doi2_10("1");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_104() {
        int ex = 7;
        int ac = Bai57_doi2to10.doi2_10("111");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_105() {
        int ex = 0;
        int ac = Bai57_doi2to10.doi2_10("11");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_106() {
        int ex = 4;
        int ac = Bai57_doi2to10.doi2_10("10");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_107() {
        int ex = 6;
        int ac = Bai57_doi2to10.doi2_10("11111");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_108() {
        int ex = 1;
        int ac = Bai57_doi2to10.doi2_10("1010");
        assertEquals(ex, ac);
    }
    
    @Test
    public void doi2_109() {
        int ex = 7;
        int ac = Bai57_doi2to10.doi2_10("1");
        assertEquals(ex, ac);
    }
}
