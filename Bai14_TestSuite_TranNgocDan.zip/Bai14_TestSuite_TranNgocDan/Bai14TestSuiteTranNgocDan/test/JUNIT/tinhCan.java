/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai74_tinhNamAmLich;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhCan {
    
    public tinhCan() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void tinhCan() {
        String ex = "Canh";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }

    @Test
    public void tinhCan1() {
        String ex = "Quy";
        String ac = Bai74_tinhNamAmLich.tinhCan(1993);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan2() {
        String ex = "Tan";
        String ac = Bai74_tinhNamAmLich.tinhCan(2001);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan3() {
        String ex = "Quy";
        String ac = Bai74_tinhNamAmLich.tinhCan(2003);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan4() {
        String ex = "Nham";
        String ac = Bai74_tinhNamAmLich.tinhCan(2002);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan5() {
        String ex = "Giap";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan6() {
        String ex = "At";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan7() {
        String ex = "Binh";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan8() {
        String ex = "Dinh";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhCan9() {
        String ex = "Mau";
        String ac = Bai74_tinhNamAmLich.tinhCan(2000);
        assertEquals(ex, ac);
    }
    
}
