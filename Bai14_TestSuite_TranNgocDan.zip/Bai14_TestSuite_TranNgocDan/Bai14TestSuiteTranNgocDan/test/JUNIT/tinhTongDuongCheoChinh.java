/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai66_xuLyMaTranVuong;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhTongDuongCheoChinh {
    
    public tinhTongDuongCheoChinh() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void tinhTongDuongCheoChinh() {
        int ex = 10;
        int[][] arr = new int[][]{{1,2,3},{2,3,4},{4,5,6}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh1() {
        int ex = 10;
        int[][] arr = new int[][]{{9,-3},{2,1}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh2() {
        int ex = 6;
        int[][] arr = new int[][]{{-3,6,4},{3,8,5},{2,1,1}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh3() {
        int ex = 14;
        int[][] arr = new int[][]{{8,9,0},{5,3,6},{1,5,3}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh4() {
        int ex = 6;
        int[][] arr = new int[][]{{1,1,1},{2,2,2},{3,3,3}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh5() {
        int ex = 1;
        int[][] arr = new int[][]{{-1}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh6() {
        int ex = 10;
        int[][] arr = new int[][]{{1,0,1},{0,1,0},{0,0,1}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh7() {
        int ex = 9;
        int[][] arr = new int[][]{{2,2},{3,3}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh8() {
        int ex = 10;
        int[][] arr = new int[][]{{4,5,6},{7,8,9},{10,11,12}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void tinhTongDuongCheoChinh9() {
        int ex = 10;
        int[][] arr = new int[][]{{0,0},{0,0}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
    
}
