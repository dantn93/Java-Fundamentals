/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai59_tinhGiaiThua;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhGiaiThua {
    
    public tinhGiaiThua() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhGiaiThua() {
        double ex = 0;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua1() {
        double ex = 24;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua2() {
        double ex = 720;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua3() {
        double ex = 1;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua4() {
        double ex = 5040;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua5() {
        double ex = 1;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua6() {
        double ex = 23;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua7() {
        double ex = 690;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua8() {
        double ex = 2;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhGiaiThua9() {
        double ex = 5041;
        double ac = Bai59_tinhGiaiThua.tinhGiaiThua(7);
        assertEquals(ex, ac, 0.01);
    }
}
