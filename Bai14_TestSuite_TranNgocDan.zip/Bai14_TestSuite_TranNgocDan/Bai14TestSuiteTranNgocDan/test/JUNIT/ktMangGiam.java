/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai63_kiemTraMangMotChieu;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class ktMangGiam {
    
    public ktMangGiam() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    //======== KIEM TRA MANG GIAM DAN ===========/
    @Test
    public void kiemTraMangGiam() {
        int[] arr = new int[]{1, 2, 3, 4, 5, 6};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertFalse(ac);
    }

    @Test
    public void kiemTraMangGiam1() {
        int[] arr = new int[]{-5, -4, -3, -2, -1};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertFalse(ac);
    }

    @Test
    public void kiemTraMangGiam2() {
        int[] arr = new int[]{0, 0, 0, 0, 0};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertTrue(ac);
    }

    @Test
    public void kiemTraMangGiam3() {
        int[] arr = new int[]{4, 5, 6, 7, 8, 9};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertFalse(ac);
    }

    @Test
    public void kiemTraMangGiam4() {
        int[] arr = new int[]{9, 8, 7, 6};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertTrue(ac);
    }

    @Test
    public void kiemTraMangGiam5() {
        int[] arr = new int[]{0, 6, 5, 4, 3};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertTrue(ac);
    }

    @Test
    public void kiemTraMangGiam6() {
        int[] arr = new int[]{4, 5, 6, 3, 7, 8};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertTrue(ac);
    }

    @Test
    public void kiemTraMangGiam7() {
        int[] arr = new int[]{4, 6, 12, 6, 7, 3};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertTrue(ac);
    }

    @Test
    public void kiemTraMangGiam8() {
        boolean ex = true;
        int[] arr = new int[]{3, 2};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertFalse(ac);
    }

    @Test
    public void kiemTraMangGiam9() {
        int[] arr = new int[]{3, 2, 1};
        boolean ac = Bai63_kiemTraMangMotChieu.kiemTraMangGiam(arr);
        assertFalse(ac);
    }

}
