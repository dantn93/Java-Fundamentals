/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai75_tinhBMI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhBMI {

    public tinhBMI() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhBMI() {
        double ex = 22.265;
        double ac = Bai75_tinhBMI.tinhBMI(57, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI1() {
        double ex = 13.148;
        double ac = Bai75_tinhBMI.tinhBMI(38, 1.7);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI2() {
        double ex = 24.691;
        double ac = Bai75_tinhBMI.tinhBMI(80, 1.8);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI3() {
        double ex = 23.437;
        double ac = Bai75_tinhBMI.tinhBMI(60, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI4() {
        double ex = 22.265;
        double ac = Bai75_tinhBMI.tinhBMI(57, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI5() {
        double ex = 20.578;
        double ac = Bai75_tinhBMI.tinhBMI(45, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI6() {
        double ex = 22.2;
        double ac = Bai75_tinhBMI.tinhBMI(40, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI7() {
        double ex = 12;
        double ac = Bai75_tinhBMI.tinhBMI(57, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI8() {
        double ex = 30.265;
        double ac = Bai75_tinhBMI.tinhBMI(57, 1.6);
        assertEquals(ex, ac, 0.01);
    }

    @Test
    public void tinhBMI9() {
        double ex = 22.265;
        double ac = Bai75_tinhBMI.tinhBMI(60, 1.6);
        assertEquals(ex, ac, 0.01);
    }
}
