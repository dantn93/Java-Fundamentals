/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai66_xuLyMaTranVuong;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class giaTriNNtrenDCC {
    
    public giaTriNNtrenDCC() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    //=== Gia tri nho nhat tren duong cheo chinh ===//
    @Test
    public void giaTriNNtrenDCC() {
        int ex = 1;
        int[][] arr = new int[][]{{1,2,3},{2,3,4},{4,5,6}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC1() {
        int ex = 1;
        int[][] arr = new int[][]{{9,-3},{2,1}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC2() {
        int ex = -3;
        int[][] arr = new int[][]{{-3,6,4},{3,8,5},{2,1,1}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC3() {
        int ex = 3;
        int[][] arr = new int[][]{{8,9,0},{5,3,6},{1,5,3}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC4() {
        int ex = 1;
        int[][] arr = new int[][]{{1,1,1},{2,2,2},{3,3,3}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC5() {
        int ex = -2;
        int[][] arr = new int[][]{{-1}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC6() {
        int ex = 10;
        int[][] arr = new int[][]{{1,0,1},{0,1,0},{0,0,1}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC7() {
        int ex = 9;
        int[][] arr = new int[][]{{2,2},{3,3}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC8() {
        int ex = 10;
        int[][] arr = new int[][]{{4,5,6},{7,8,9},{10,11,12}};
        int ac = Bai66_xuLyMaTranVuong.giaTriNNtrenDCC(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void giaTriNNtrenDCC9() {
        int ex = 10;
        int[][] arr = new int[][]{{0,0},{0,0}};
        int ac = Bai66_xuLyMaTranVuong.tinhTongDuongCheoChinh(arr);
        assertEquals(ex, ac);
    }
}
