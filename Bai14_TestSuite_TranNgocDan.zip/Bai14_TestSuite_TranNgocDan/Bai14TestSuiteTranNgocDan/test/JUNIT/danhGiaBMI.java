/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai75_tinhBMI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *
 * @author snow
 */
public class danhGiaBMI {
    
    public danhGiaBMI() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    @Test
    public void danhGiaBMI() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(57, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI1() {
        String ex = "Gay";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(38, 1.7));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI2() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(80, 1.8));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI3() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(60, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI4() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(57, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI5() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(45, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI6() {
        String ex = "Binh thuong";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(40, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI7() {
        String ex = "Thua can";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(57, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI8() {
        String ex = "Thua can";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(57, 1.6));
        assertEquals(ex, ac);
    }

    @Test
    public void danhGiaBMI9() {
        String ex = "Thua can";
        String ac = Bai75_tinhBMI.danhGiaBMI(Bai75_tinhBMI.tinhBMI(60, 1.6));
        assertEquals(ex, ac);
    }
}