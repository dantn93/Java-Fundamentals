/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;


import bai7tranngocdan.Bai54_tinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhE {
    
    public tinhE() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhE() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhE(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE1() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhE(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE2() {
        double ex = 10;
        double ac = Bai54_tinhGTBT.tinhE(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE3() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhE(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE4() {
        double ex = 17;
        double ac = Bai54_tinhGTBT.tinhE(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE5() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhE(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE6() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhE(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE7() {
        double ex = 6;
        double ac = Bai54_tinhGTBT.tinhE(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE8() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhE(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhE9() {
        double ex = 14;
        double ac = Bai54_tinhGTBT.tinhE(7);
        assertEquals(ex, ac, 0.01);
    }
}
