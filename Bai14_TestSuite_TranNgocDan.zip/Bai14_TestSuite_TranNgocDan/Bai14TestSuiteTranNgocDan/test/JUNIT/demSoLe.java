/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai65_xuLyMangHaiChieu;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class demSoLe {
    
    public demSoLe() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    //===Dem so le===//
    @Test
    public void demSoLe() {
        int ex = 4;
        int[][] arr = new int[][]{{1,2,3,5},{2,4,5,6}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe1() {
        int ex = 0;
        int[][] arr = new int[][]{{0,0,0},{0,0,0}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe2() {
        int ex = 0;
        int[][] arr = new int[][]{{2,2},{2,2}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe3() {
        int ex = 6;
        int[][] arr = new int[][]{{1,1,1},{1,1,1}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe4() {
        int ex = 3;
        int[][] arr = new int[][]{{-1,2,3},{-2,2,3}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        //System.out.println(Bai65_xuLyMangHaiChieu.demSoLe(arr));
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe5() {
        int ex = 3;
        int[][] arr = new int[][]{{5,6,7,8},{2,3,4,5}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe6() {
        int ex = 2;
        int[][] arr = new int[][]{{6,7,8},{3,4,5}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe7() {
        int ex = 4;
        int[][] arr = new int[][]{{1,3,5,7,9},{0,2,4,6,8}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe8() {
        int ex = 0;
        int[][] arr = new int[][]{{5,6,7,8,9},{1,2,3,4,5}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
    @Test
    public void demSoLe9() {
        int ex = 2;
        int[][] arr = new int[][]{{0,0,0,0},{1,1,1,1}};
        int ac = Bai65_xuLyMangHaiChieu.demSoLe(arr);
        assertEquals(ex, ac);
    }
    
}
