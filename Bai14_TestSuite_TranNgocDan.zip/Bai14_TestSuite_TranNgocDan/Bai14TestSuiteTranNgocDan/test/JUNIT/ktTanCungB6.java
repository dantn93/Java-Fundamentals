/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai63_kiemTraMangMotChieu;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class ktTanCungB6 {
    
    public ktTanCungB6() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    //=======KIEM TRA SO CO TAN CUNG BANG 6 =========//
    @Test
    public void kiemTraTanCung6() {
        int ex = 6;
        int[] arr = new int[]{1, 2, 3, 4, 5, 6};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_1() {
        int ex = -1;
        int[] arr = new int[]{-5, -4, -3, -2, -1};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_2() {
        int ex = -1;
        int[] arr = new int[]{0, 0, 0, 0, 0};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_3() {
        int ex = 6;
        int[] arr = new int[]{4, 5, 6, 7, 8, 9};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_4() {
        int ex = 6;
        int[] arr = new int[]{9, 8, 7, 6};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_5() {
        int ex = 1;
        int[] arr = new int[]{0, 6, 5, 4, 3};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_6() {
        int ex = 36;
        int[] arr = new int[]{4, 5, 6, 3, 7, 8};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_7() {
        int ex = -1;
        int[] arr = new int[]{4, 6, 12, 6, 7, 3};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_8() {
        int ex = 6;
        int[] arr = new int[]{3, 2};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }

    @Test
    public void kiemTraTanCung6_9() {
        int ex = 5;
        int[] arr = new int[]{3, 2, 1};
        int ac = Bai63_kiemTraMangMotChieu.kiemTraTanCung6(arr);
        assertEquals(ac, ex);
    }
}
