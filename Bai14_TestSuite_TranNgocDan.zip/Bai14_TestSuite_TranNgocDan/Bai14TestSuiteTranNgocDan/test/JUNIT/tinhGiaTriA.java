/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;

import bai7tranngocdan.Bai52_tinhA;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhGiaTriA {
    
    public tinhGiaTriA() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhA() {
        double ex = 2;
        double ac = Bai52_tinhA.tinhA(0, 0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA1() {
        double ex = 1.11;
        double ac = Bai52_tinhA.tinhA(1, -2);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA2() {
        double ex = 370;
        double ac = Bai52_tinhA.tinhA(2, 3);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA3() {
        double ex = 52;
        double ac = Bai52_tinhA.tinhA(-5, 1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA4() {
        double ex = 2;
        double ac = Bai52_tinhA.tinhA(-1, 0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA5() {
        double ex = 4;
        double ac = Bai52_tinhA.tinhA(0, -1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA6() {
        double ex = 6;
        double ac = Bai52_tinhA.tinhA(1, 2);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA7() {
        double ex = 2;
        double ac = Bai52_tinhA.tinhA(-1, -2);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA8() {
        double ex = 5;
        double ac = Bai52_tinhA.tinhA(2, 7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA9() {
        double ex = 7;
        double ac = Bai52_tinhA.tinhA(-3, 10);
        assertEquals(ex, ac, 0.01);
    }
}
