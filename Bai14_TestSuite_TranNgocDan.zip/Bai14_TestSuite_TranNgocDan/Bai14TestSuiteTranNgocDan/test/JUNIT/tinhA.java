/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;


import bai7tranngocdan.Bai54_tinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhA {
    
    public tinhA() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhA() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhA(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA1() {
        double ex = 4;
        double ac = Bai54_tinhGTBT.tinhA(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA2() {
        double ex = 9;
        double ac = Bai54_tinhGTBT.tinhA(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA3() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhA(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA4() {
        double ex = 16;
        double ac = Bai54_tinhGTBT.tinhA(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA5() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhA(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA6() {
        double ex = 2;
        double ac = Bai54_tinhGTBT.tinhA(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA7() {
        double ex = 13;
        double ac = Bai54_tinhGTBT.tinhA(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA8() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhA(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhA9() {
        double ex = 14;
        double ac = Bai54_tinhGTBT.tinhA(7);
        assertEquals(ex, ac, 0.01);
    }
}
