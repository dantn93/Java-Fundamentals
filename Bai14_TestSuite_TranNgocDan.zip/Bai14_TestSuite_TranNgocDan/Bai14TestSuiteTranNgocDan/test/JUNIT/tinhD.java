/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;


import bai7tranngocdan.Bai54_tinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhD {
    
    public tinhD() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhD() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhD(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD1() {
        double ex = 3;
        double ac = Bai54_tinhGTBT.tinhD(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD2() {
        double ex = 18;
        double ac = Bai54_tinhGTBT.tinhD(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD3() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhD(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD4() {
        double ex = 18;
        double ac = Bai54_tinhGTBT.tinhD(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD5() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhD(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD6() {
        double ex = 4;
        double ac = Bai54_tinhGTBT.tinhD(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD7() {
        double ex = 4;
        double ac = Bai54_tinhGTBT.tinhD(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD8() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhD(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhD9() {
        double ex = 14;
        double ac = Bai54_tinhGTBT.tinhD(7);
        assertEquals(ex, ac, 0.01);
    }
}
