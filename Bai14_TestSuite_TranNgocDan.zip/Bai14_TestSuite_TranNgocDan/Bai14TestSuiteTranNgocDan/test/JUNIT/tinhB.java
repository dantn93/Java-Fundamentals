/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JUNIT;


import bai7tranngocdan.Bai54_tinhGTBT;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author snow
 */
public class tinhB {
    
    public tinhB() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void tinhB() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhB(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB1() {
        double ex = 6;
        double ac = Bai54_tinhGTBT.tinhB(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB2() {
        double ex = 12;
        double ac = Bai54_tinhGTBT.tinhB(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB3() {
        double ex = 0;
        double ac = Bai54_tinhGTBT.tinhB(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB4() {
        double ex = 12;
        double ac = Bai54_tinhGTBT.tinhB(7);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB5() {
        double ex = 1;
        double ac = Bai54_tinhGTBT.tinhB(0);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB6() {
        double ex = 7;
        double ac = Bai54_tinhGTBT.tinhB(4);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB7() {
        double ex = 13;
        double ac = Bai54_tinhGTBT.tinhB(6);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB8() {
        double ex = 5;
        double ac = Bai54_tinhGTBT.tinhB(1);
        assertEquals(ex, ac, 0.01);
    }
    
    @Test
    public void tinhB9() {
        double ex = 14;
        double ac = Bai54_tinhGTBT.tinhB(7);
        assertEquals(ex, ac, 0.01);
    }
}