/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test_Suite;

import JUNIT.ktSoNguyenTo;
import JUNIT.timX;
import JUNIT.ktMangGiam;
import JUNIT.ktMangTang;
import JUNIT.ktTanCungB6;
import JUNIT.ktPhanTuAm;
import JUNIT.phanTuLN_NN;
import JUNIT.giaTriLNtrenDCC;
import JUNIT.giaTriNNtrenDCC;
import JUNIT.tinhCan;
import JUNIT.tinhChi;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author snow
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
    ktSoNguyenTo.class,
    timX.class,
    ktMangGiam.class,
    ktMangTang.class,
    ktTanCungB6.class,
    ktPhanTuAm.class,
    phanTuLN_NN.class,
    giaTriLNtrenDCC.class,
    giaTriNNtrenDCC.class,
    tinhCan.class,
    tinhChi.class
})
public class timKiem {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
