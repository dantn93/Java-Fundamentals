/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test_Suite;

import JUNIT.tinhGiaTriA;
import JUNIT.haiLanGiaiThua;
import JUNIT.tinhGiaiThua;
import JUNIT.tinhTong;
import JUNIT.demSoChan;
import JUNIT.demSoLe;
import JUNIT.tinhTrungBinhChan;
import JUNIT.tinhTrungBinhLe;
import JUNIT.tinhTongDuongCheoChinh;
import JUNIT.tinhBMI;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import JUNIT.*;
/**
 *
 * @author snow
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
    tinhA.class,
    tinhB.class,
    tinhC.class,
    tinhD.class,
    tinhE.class,
    tinhGiaTriA.class,
    haiLanGiaiThua.class,
    tinhGiaiThua.class,
    tinhTong.class,
    demSoChan.class,
    demSoLe.class,
    tinhTrungBinhChan.class ,
    tinhTrungBinhLe.class ,
    tinhTongDuongCheoChinh.class,
    tinhBMI.class
        
        
})
public class tinhGTBT {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
}
