/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class Bai58_bangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here

        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("*******************************************************************");
            System.out.println("In bang cuu chuong");
            System.out.println("*******************************************************************");
            System.out.print("Tu so: ");
            int a = Integer.parseInt(input.readLine());
            System.out.print("Den so: ");
            int b = Integer.parseInt(input.readLine());
            System.out.println("--------------------------------------------------------------------");
            //In bang cuu chuong
            inBangCC(a, b);
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static void inBangCC(int a, int b) {
        if(a > b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        if (a <= b) {
            for (int i = 1; i <= 9; i++) {
                for (int j = a; j <= b; j++) {
                    System.out.print(j + " x " + i + " = " + j * i + "\t");
                }
                System.out.print("\n");
            }
        } else {
            System.out.println("a < b. Hay nhap lai.");
        }
    }
}
