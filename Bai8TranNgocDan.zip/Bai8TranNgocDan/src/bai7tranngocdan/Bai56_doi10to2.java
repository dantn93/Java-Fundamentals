/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

/**
 *
 * @author snow
 */
public class Bai56_doi10to2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap so thap phan n: ");
            int n = Integer.parseInt(input.readLine());
            if (n < 0) {
                throw new ArithmeticException("n < 0");
            }
            //So nguyen duong
            while (n < 0) {
                System.out.print("Nhap lai: ");
                n = Integer.parseInt(input.readLine());
            }

            System.out.println(doi10_2(n));
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }

    }

    public static String doi10_2(int n) {
        String arr = "";
        int i = 0;
        if (n > 0) {
            while (n > 0) {
                i = n % 2;
                arr = arr + Integer.toString(i);
                n = n / 2;
                if (n == 1) {
                    arr += Integer.toString(1);
                    break;
                }
            }
            String kq = "";
            for (i = arr.length() - 1; i >= 0; i--) {
                kq += arr.charAt(i);
            }
            return kq;
        } else {
            return "0";
        }
    }
}
