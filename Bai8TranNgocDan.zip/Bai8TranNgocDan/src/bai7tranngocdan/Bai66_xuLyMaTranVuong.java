/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai66_xuLyMaTranVuong {

    /**
     * @param args the command line arguments
     */
    public static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

    public static void xuatMang(int n, int[][] arr) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(arr[i][j] + "  ");
            }
            System.out.println("");
        }
    }

    public static int tinhTongDuongCheoChinh(int n, int[][] arr) {
        int tong = 0;
        for (int i = 0; i < n; i++) {
            tong += arr[i][i];
        }
        return tong;
    }

    public static int giaTriLNtrenDCC(int n, int[][] arr) {
        int sLN = 0;
        for (int i = 0; i < n; i++) {
            if (sLN < arr[i][i]) {
                sLN = arr[i][i];
            }
        }
        return sLN;
    }

    public static int giaTriNNtrenDCC(int n, int[][] arr) {
        int sNN = 0;
        for (int i = 0; i < n; i++) {
            if (sNN > arr[i][i]) {
                sNN = arr[i][i];
            }
        }
        return sNN;
    }

    public static boolean kiemTraSNT(int n) {
        if (n < 0 || n == 0 || n == 1) {
            return false;
        } else {
            int m = n / 2;
            for (int i = 2; i <= m; i++) {
                if (n % i == 0) {
                    return false;
                }
            }
            return true;
        }
    }

    //Kiem tra ma tran doi xung qua duong cheo chinh
    public static boolean ktDoiXung(int n, int[][] arr) {
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (arr[i][j] != arr[j][i]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static int[][] nhapMaTranNgauNhien(int n) {
        int[][] arr = new int[n][n];
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                arr[i][j] = rand.nextInt(20);
            }
        }
        return arr;
    }

    public static int[][] nhapMaTranBT(int n) throws IOException {
        int[][] b = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                b[i][j] = Integer.parseInt(input.readLine());
            }
        }
        return b;
    }

    public static void kiemTraCot(int k, int[][] c) {
        int n = c.length;
        //Kiem tra cot k tang dan, giam dan
        int cTang = 0;
        int cGiam = 0;
        for (int i = 0; i < n - 1; i++) {
            if (c[i][k] < c[i + 1][k]) {
                cTang++;
            }
            if (c[i][k] > c[i + 1][k]) {
                cGiam++;
            }
        }
        if (cTang == n - 1) {
            System.out.println("Cot k tang dan");
        }
        if (cGiam == n - 1) {
            System.out.println("Cot k giam dan");
        }
        if (cTang != n - 1 || cGiam != n - 1) {
            System.out.println("Cot k KHONG tang, KHONG giam");
        }
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            System.out.print("Nhap m: ");
            int n = Integer.parseInt(input.readLine());
            if (n <= 0) {
                throw new ArithmeticException("So phan tu cua mang n <= 0");
            }
            int[][] arr = nhapMaTranNgauNhien(n);

            //Xuat ma tran vuong
            xuatMang(n, arr);
            //Tinh tong duong cheo chinh
            System.out.println("Tong cac gia tri tren duong cheo chinh: " + tinhTongDuongCheoChinh(n, arr));
            System.out.println("Gia tri LON nhat tren duong cheo chinh: " + giaTriLNtrenDCC(n, arr));
            System.out.println("Gia tri NHO nhat tren duong cheo chinh: " + giaTriNNtrenDCC(n, arr));

            //Kiem tra va in ra so nguyen to
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (kiemTraSNT(arr[i][j])) {
                        System.out.println("So nguyen to a[" + i + "][" + j + "] = " + arr[i][j]);
                    }
                }
            }

            //Khoi tao va nhap gia tri ma tran vuong b
            System.out.println("Nhap ma tran vuong b");
            int[][] b = nhapMaTranBT(n);
            //Xuat ma tran vuong b
            xuatMang(n, b);
            //Kiem tra doi xung
            if (ktDoiXung(n, b)) {
                System.out.println("Ma tran b doi xung qua duong cheo chinh");
            } else {
                System.out.println("Ma tran b KHONG doi xung qua duong cheo chinh");
            }

            //Khoi tao ma tran c
            int[][] c = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    c[i][j] = arr[i][j] + b[i][j];
                }
            }
            //Xuat ma tran c
            System.out.println("Xuat ma tran vuong c");
            xuatMang(n, c);
            System.out.print("Nhap cot k: ");
            int k = Integer.parseInt(input.readLine());
            if (k < 0 || k >= n) {
                throw new ArithmeticException("Cot k nam ngoai ma tran");
            }
            //Kiem tra cot k tang dan, giam dan
            kiemTraCot(k, c);
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

}
