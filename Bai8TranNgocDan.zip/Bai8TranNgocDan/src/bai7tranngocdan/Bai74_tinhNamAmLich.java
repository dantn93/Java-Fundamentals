/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai74_tinhNamAmLich {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap nam sinh: ");
            int namSinh = Integer.parseInt(input.readLine());
            while (namSinh < 0) {
                System.out.print("Nhap lai: ");
                namSinh = Integer.parseInt(input.readLine());
            }
            System.out.println("Nam am lich: " + tinhCan(namSinh) + " " + tinhChi(namSinh));
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static String tinhCan(int y) {
        switch (y % 10) {
            case 1:
                return "Tan";
            case 2:
                return "Nham";
            case 3:
                return "Quy";
            case 4:
                return "Giap";
            case 5:
                return "At";
            case 6:
                return "Binh";
            case 7:
                return "Dinh";
            case 8:
                return "Mau";
            case 9:
                return "Ky";
            case 0:
                return "Canh";

        }
        return "";
    }

    public static String tinhChi(int y) {
        switch (y % 12) {
            case 1:
                return "Dau";
            case 2:
                return "Tuat";
            case 3:
                return "Hoi";
            case 4:
                return "Ty";
            case 5:
                return "Suu";
            case 6:
                return "Dan";
            case 7:
                return "Mao";
            case 8:
                return "Thin";
            case 9:
                return "Ty";
            case 10:
                return "Ngo";
            case 11:
                return "Mui";

        }
        return "";
    }

}
