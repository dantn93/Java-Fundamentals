/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.sqrt;

/**
 *
 * @author snow
 */
public class Bai53_ktSoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap x: ");
            int x = Integer.parseInt(input.readLine());
            if(x < 0) throw new ArithmeticException("x < 0");
            if (ktSNT(x)) {
                System.out.println(x + " la so nguyen to");
            } else {
                System.out.println(x + " KHONG la so nguyen to");
            }

        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }

    }

    public static boolean ktSNT(int x) {
        if (x >= 2) {
            int m = (int) sqrt(x);
            for (int i = 2; i <= m; i++) {
                if (x % i == 0) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
}
