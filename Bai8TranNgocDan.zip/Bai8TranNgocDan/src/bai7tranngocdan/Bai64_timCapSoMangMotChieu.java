/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

/**
 *
 * @author hocvien
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Bai64_timCapSoMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

    public static void xuatMang(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    public static int[] nhapMang(int n) throws IOException {
        System.out.println("Nhap gia tri cho cac phan tu trong mang: ");
        int[] arr = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Phan tu thu " + i + ": ");
            arr[i] = Integer.parseInt(input.readLine());
        }
        return arr;
    }

    public static void quanHeChiaHet(int[] arr) {
        System.out.println("Cap so co quan he chia het:");
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] % arr[j] == 0) || (arr[j] % arr[i] == 0)) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

    public static void quanHeGapDoi(int[] arr) {
        System.out.println("Cap so co quan he gap doi:");
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (((arr[i] % arr[j] == 0) && (arr[i] / arr[j] == 2))
                        || ((arr[j] % arr[i] == 0) && arr[j] / arr[i] == 2)) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

    public static void quanHeTongb8(int[] arr) {
        System.out.println("Cap so co quan he tong bang 8:");
        int count = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] + arr[j] == 8) {
                    System.out.println(arr[i] + " & " + arr[j]);
                    count++;
                }
            }
        }
        if (count == 0) {
            System.out.println("Khong co!");
        }
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap n: ");
            int n = Integer.parseInt(input.readLine());
            if (n <= 0) {
                throw new ArithmeticException("So phan tu cua mang <= 0");
            }
            int[] arr = nhapMang(n);

            //Xuat mang a
            xuatMang(arr);
            //Quan he chia het
            quanHeChiaHet(arr);
            //Quan he gap doi
            quanHeGapDoi(arr);
            //Quan he co tong bang 8
            quanHeTongb8(arr);
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

}
