/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai75_tinhBMI {

    final static double GAY = 18.5;
    final static double BT = 24.99;
    final static double THUA = 25;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chieu cao: ");
            double cCao = Double.parseDouble(input.readLine());
            while (cCao <= 0) {
                System.out.print("Nhap lai: ");
                cCao = Double.parseDouble(input.readLine());
            }
            System.out.print("Nhap can nang: ");
            double cNang = Double.parseDouble(input.readLine());
            while (cNang <= 0) {
                System.out.print("Nhap lai: ");
                cNang = Double.parseDouble(input.readLine());
            }

            double BMI = tinhBMI(cNang, cCao);
            System.out.println("Chi so BMI cua co the: " + BMI);
            System.out.println("Ket luan: " + danhGiaBMI(BMI));
        } catch (NullPointerException | NumberFormatException | ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }

    }

    public static double tinhBMI(double nang, double cao) {
        return (double) (nang / (cao * cao));
    }

    public static String danhGiaBMI(double BMI) {
        if (BMI < GAY) {
            return "Gay";
        } else if (BMI >= GAY && BMI <= BT) {
            return "Binh thuong";
        } else if (BMI >= 25) {
            return "Thua Can";
        } else {
            return "";
        }
    }

}
