/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai8tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.sqrt;

/**
 *
 * @author hocvien
 */
public class tinhToanBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap x: ");

            int x = Integer.parseInt(input.readLine());
            System.out.print("Nhap y: ");
            int y = Integer.parseInt(input.readLine());

            int tu = 5 * x - y;
            int mau = 2 * x + 7 * y;

            double A = tinhA(tu, mau);
            System.out.println("A = " + A);

        } catch (NumberFormatException|ArithmeticException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static double tinhA(int x, int y) {
        double A = 0;
        if (y == 0) {
            throw new ArithmeticException("mau so bang 0");
        }
        if (x * y < 0) {
            throw new ArithmeticException("can bac 2 cua so am");
        }
        A = sqrt((double)x / (double)y);
        return A;
    }
}
