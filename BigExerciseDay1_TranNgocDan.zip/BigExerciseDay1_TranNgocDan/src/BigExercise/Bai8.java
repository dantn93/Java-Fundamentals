/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import static BigExercise.Bai5.inMang;
import static BigExercise.Bai5.phatSinhNgauNhien;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap n: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //=== Tao mang mot chieu ===//
            System.out.println("=== Diem sinh vien ===");
            int[] arr = phatSinhNgauNhien(n);
            inMang(arr);
            //===Thong ke===//
            System.out.println("\n===Thong ke===");
            int[] tk = thongKe(arr);
            System.out.println("0 - 9: "+tk[0]);
            System.out.println("10 - 19: "+tk[1]);
            System.out.println("20 - 29: "+tk[2]);
            System.out.println("30 - 39: "+tk[3]);
            System.out.println("40 - 49: "+tk[4]);
            System.out.println("50 - 59: "+tk[5]);
            System.out.println("60 - 69: "+tk[6]);
            System.out.println("70 - 79: "+tk[7]);
            System.out.println("80 - 89: "+tk[8]);
            System.out.println("90 - 100: "+tk[9]);
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }

    }

    public static int[] phatSinhNgauNhien(int n) {
        Random rd = new Random();
        int[] arr = new int[n];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rd.nextInt(101);
        }
        return arr;
    }

    public static void inMang(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println("arr[" + i + "] = " + arr[i]);
        }
    }

    public static int[] thongKe(int[] arr) {
        int[] khoang = new int[10];
        for (int i = 0; i < khoang.length; i++) {
            khoang[i] = 0;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] >= 0 && arr[i] <= 9) {
                khoang[0]++;
            }
            if (arr[i] >= 10 && arr[i] <= 19) {
                khoang[1]++;
            }
            if (arr[i] >= 20 && arr[i] <= 29) {
                khoang[2]++;
            }
            if (arr[i] >= 30 && arr[i] <= 39) {
                khoang[3]++;
            }
            if (arr[i] >= 40 && arr[i] <= 49) {
                khoang[4]++;
            }
            if (arr[i] >= 50 && arr[i] <= 59) {
                khoang[5]++;
            }
            if (arr[i] >= 60 && arr[i] <= 69) {
                khoang[6]++;
            }
            if (arr[i] >= 70 && arr[i] <= 79) {
                khoang[7]++;
            }
            if (arr[i] >= 80 && arr[i] <= 89) {
                khoang[8]++;
            }
            if (arr[i] >= 90 && arr[i] <= 100) {
                khoang[9]++;
            }
            
        }
        return khoang;
    }

}
