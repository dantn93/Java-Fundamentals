/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author hocvien
 */
public class Bai9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Create arrays & variables  
        int[][] arr = new int[9][9];
        arr[0] = maTranNgauNhien();
        int[] mt = new int[9];
        int count = 9;
        for (int i = 1; i < 9; i++) {
            while (true) {
                mt = maTranNgauNhien();
                int cnt = 0;
                for (int k = 0; k < i; k++) {
                    for (int j = 0; j < 9; j++) {
                        if (mt[j] != arr[k][j]) {
                            cnt++;
                        }
                    }
                }
                if (cnt == 9 * i) {
                    arr[i] = mt;
                    break;
                }
            }

        }
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                System.out.print(arr[i][j] + " ");

            }
            System.out.println("");
        }

    }

    public static int[] maTranNgauNhien() {
        int[] ds = new int[9];
        for (int i = 0; i < 9; i++) {
            ds[i] = -1;
        }

        Random rd = new Random();
        ds[0] = rd.nextInt(9) + 1;
        boolean flag = true;
        int dem = 1;

        while (flag) {
            int count = 0;
            for (int i = 0; i < 9; i++) {
                if (ds[i] > -1) {
                    count++;
                }
            }
            if (count == 9) {
                break;
            }
            //else
            int x = rd.nextInt(9) + 1;
            int dem1 = 0;
            for (int i = 0; i < dem; i++) {
                if (ds[i] != x) {
                    dem1++;
                }
            }
            if (dem1 == dem) {
                ds[dem] = x;
                dem++;
            }

        }
        return ds;
    }
}
