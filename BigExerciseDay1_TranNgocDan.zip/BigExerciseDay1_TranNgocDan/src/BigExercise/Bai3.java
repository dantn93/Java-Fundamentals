/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import static BigExercise.Bai1.ktTenGoi;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai3 {

    /**
     * @param args the command line arguments
     */
    final static double A2T = 129000;
    final static double A2TL = 128000;
    final static double AnLT1 = 249000;
    final static double AnLT2 = 218000;
    final static double AnT1 = 202000;
    final static double AnT2 = 172000;
    final static double BnLT1 = 214000;
    final static double BnLT2 = 189000;
    final static double BnLT3 = 163000;
    final static double BnT1 = 193000;
    final static double BnT2 = 168000;
    final static double BnT3 = 146000;
    final static double GP = 79000;
    final static double NC = 99000;
    final static double NCL = 116000;
    final static double NM = 129000;
    final static double NML = 155000;
    final static double NML4V = 171000;
    final static double TRE_EM = 0.5;
    final static double GIA = 0.7;

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap loai ghe: ");
            String loaiGhe = input.readLine();

            //=== Kiem tra loai ghe hop le ===//
            while (true) {
                if (!ktTenGoi(loaiGhe)) {
                    System.out.print("Ten goi sai! Xin hay nhap lai: ");
                    loaiGhe = input.readLine();
                } else {
                    break;
                }
            }
            //===Nhap tong so ve muon mua===//
            System.out.print("Nhap tong so ve: ");
            int tongVe = Integer.parseInt(input.readLine());
            while (true) {
                if (tongVe <= 0) {
                    System.out.print("Ban nhap sai! Hay nhap lai: ");
                    tongVe = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            
            System.out.print("So ve nguoi lon: ");
            int veLon = Integer.parseInt(input.readLine());
            while (true) {
                if (veLon < 0 || veLon > tongVe) {
                    System.out.print("Ban nhap sai! Hay nhap lai: ");
                    veLon = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }

            System.out.print("So ve tre em: ");
            int veTreEm = Integer.parseInt(input.readLine());
            while (true) {
                if (veTreEm < 0 || veTreEm+veLon > tongVe) {
                    System.out.print("Ban nhap sai! Hay nhap lai: ");
                    veTreEm = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            
            int veGia = tongVe - veLon - veTreEm;
            
            //=== Tinh tien ve ===//
            double[] tienVe = tinhTienVe(loaiGhe, veLon, veTreEm, veGia);
            //=== In thong tin ===//
            System.out.println("=== In thong tin ===");
            System.out.println("Tong so ve: "+tongVe);
            System.out.println("Ve nguoi lon: "+veLon+" ve. Thanh tien: "+tienVe[0]+" vnd");
            System.out.println("Ve tre em: "+veTreEm+" ve. Thanh tien: "+tienVe[1]+" vnd");
            System.out.println("Ve nguoi gia: "+veGia+" ve. Thanh tien: "+tienVe[2]+" vnd");
            System.out.println("Tong so tien: "+(double)(tienVe[0]+tienVe[1]+tienVe[2])+" vnd");
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static boolean ktTenGoi(String tenGoi) {
        boolean flag = false;
        switch (tenGoi.toUpperCase()) {
            case "A2T":
            case "A2TL":
            case "AnLT1":
            case "AnLT2":
            case "AnT1":
            case "AnT2":
            case "BnLT1":
            case "BnLT2":
            case "BnLT3":
            case "BnT1":
            case "BnT2":
            case "BnT3":
            case "GP":
            case "NC":
            case "NCL":
            case "NM":
            case "NML":
            case "NML4V":
                return true;
        }
        return false;
    }
    public static double[] tinhTienVe(String ghe, int nlon, int treem, int gia){
        double[] arr = new double[3];
        switch (ghe.toUpperCase()) {
            case "A2T":
                arr[0] = A2T*nlon;
                arr[1] = A2T*treem*TRE_EM;
                arr[2] = A2T*gia*GIA;
                return arr;
            case "A2TL":
                arr[0] = A2TL*nlon;
                arr[1] = A2TL*treem*TRE_EM;
                arr[2] = A2TL*gia*GIA;
                return arr;
            case "AnLT1":
                arr[0] = AnLT1*nlon;
                arr[1] = AnLT1*treem*TRE_EM;
                arr[2] = AnLT1*gia*GIA;
                return arr;
            case "AnLT2":
                arr[0] = AnLT2*nlon;
                arr[1] = AnLT2*treem*TRE_EM;
                arr[2] = AnLT2*gia*GIA;
                return arr;
            case "AnT1":
                arr[0] = AnT1*nlon;
                arr[1] = AnT1*treem*TRE_EM;
                arr[2] = AnT1*gia*GIA;
                return arr;
            case "AnT2":
                arr[0] = AnT2*nlon;
                arr[1] = AnT2*treem*TRE_EM;
                arr[2] = AnT2*gia*GIA;
                return arr;
            case "BnLT1":
                arr[0] = BnLT1*nlon;
                arr[1] = BnLT1*treem*TRE_EM;
                arr[2] = BnLT1*gia*GIA;
                return arr;
            case "BnLT2":
                arr[0] = BnLT2*nlon;
                arr[1] = BnLT2*treem*TRE_EM;
                arr[2] = BnLT2*gia*GIA;
                return arr;
            case "BnLT3":
                arr[0] = BnLT3*nlon;
                arr[1] = BnLT3*treem*TRE_EM;
                arr[2] = BnLT3*gia*GIA;
                return arr;
            case "BnT1":
                arr[0] = BnT1*nlon;
                arr[1] = BnT1*treem*TRE_EM;
                arr[2] = BnT1*gia*GIA;
                return arr;
            case "BnT2":
                arr[0] = BnT2*nlon;
                arr[1] = BnT2*treem*TRE_EM;
                arr[2] = BnT2*gia*GIA;
                return arr;
            case "BnT3":
                arr[0] = BnT3*nlon;
                arr[1] = BnT3*treem*TRE_EM;
                arr[2] = BnT3*gia*GIA;
                return arr;
            case "GP":
                arr[0] = GP*nlon;
                arr[1] = GP*treem*TRE_EM;
                arr[2] = GP*gia*GIA;
                return arr;
            case "NC":
                arr[0] = NC*nlon;
                arr[1] = NC*treem*TRE_EM;
                arr[2] = NC*gia*GIA;
                return arr;
            case "NCL":
                arr[0] = NCL*nlon;
                arr[1] = NCL*treem*TRE_EM;
                arr[2] = NCL*gia*GIA;
                return arr;
            case "NM":
                arr[0] = NM*nlon;
                arr[1] = NM*treem*TRE_EM;
                arr[2] = NM*gia*GIA;
                return arr;
            case "NML":
                arr[0] = NML*nlon;
                arr[1] = NML*treem*TRE_EM;
                arr[2] = NML*gia*GIA;
                return arr;
            case "NML4V":
                arr[0] = NML4V*nlon;
                arr[1] = NML4V*treem*TRE_EM;
                arr[2] = NML4V*gia*GIA;
                return arr;
        }
        return arr;
    }

}
