/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap kich thuoc ma tran vuong n: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (!ktNhapKichThuoc(n)) {
                    System.out.println("Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //===Nhap cac phan tu cua ma tran vuong ===//
            int[][] matrix = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print("a[" + i + "][" + j + "] = ");
                    matrix[i][j] = Integer.parseInt(input.readLine());
                }
            }
            //===In ma tran===//
            System.out.println("===In ma tran===");
            inMaTran(matrix);
            //===Tim phan tu LN & NN cua moi dong===//
            int[][] max_min = timPTLN_NNmoiDong(matrix);
            System.out.println("===Phan tu LN & NN cua moi dong===");
            for (int i = 0; i < max_min.length; i++) {
                System.out.println("Dong " + i + " - GTLN: " + max_min[i][0] + " / GTNN: " + max_min[i][1]);
            }

            //===Thay cac gia tri tren DCC va DCP bang gia tri nay===//
            System.out.println("===Thay cac gia tri tren DCC va DCP bang gia tri nay===");
            System.out.print("Nhap x: ");
            int x = Integer.parseInt(input.readLine());
            matrix = thayGiaTri(x, matrix);
            inMaTran(matrix);

            //===Tim phan tu am LN va phan tu duong NN trong ma tran===//
            System.out.println("===Tim phan tu am LN va phan tu duong NN trong ma tran===");
            int[] amLNduongNN = timPtAmLNDuongNN(matrix);
            System.out.println("So am lon nhat: " + amLNduongNN[0]);
            System.out.println("So duong nho nhat: " + amLNduongNN[1]);
            
            //===Dem phan tu duong trong tam giac phia tren duong cheo chinh ===//
            System.out.println("===Dem phan tu duong trong tam giac phia tren duong cheo chinh===");
            System.out.println("So phan tu duong: "+demPhanTuDuong(matrix));
            //===Dem so am chia het cho 2 va cho 3===//
            System.out.println("===Dem so am chia het cho 2 va cho 3===");
            System.out.println("Dem so am chia het cho 2 va 3: "+demSoAm(matrix));
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }

    }

    public static boolean ktNhapKichThuoc(int n) {
        if (n <= 0) {
            return false;
        } else {
            return true;
        }
    }

    public static void inMaTran(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println("");
        }
    }

    public static int[][] timPTLN_NNmoiDong(int[][] arr) {
        int[][] max_min = new int[arr.length][2];
        for (int i = 0; i < arr.length; i++) {
            int max = arr[i][0];
            int min = arr[i][0];
            for (int j = 1; j < arr[i].length; j++) {
                if (max < arr[i][j]) {
                    max = arr[i][j];
                }
                if (min > arr[i][j]) {
                    min = arr[i][j];
                }
            }
            max_min[i][0] = max;
            max_min[i][1] = min;
        }
        return max_min;

    }

    public static int[][] thayGiaTri(int x, int[][] mt) {
        int[][] arr = new int[mt.length][mt.length];
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[0].length; j++) {
                arr[i][j] = mt[i][j];
            }
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                arr[i][i] = x;
                arr[i][arr[i].length - 1 - i] = x;
            }
        }
        return arr;
    }

    public static int[] timPtAmLNDuongNN(int[][] arr) {
        int[] max_min = new int[]{0, 0};
        boolean flag1 = true;
        boolean flag2 = true;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                //Phan tu am lon nhat
                if (arr[i][j] < 0 && flag1 == true) {
                    max_min[0] = arr[i][j];
                    flag1 = false;
                }
                if (arr[i][j] < 0 && arr[i][j] > max_min[0]) {
                    max_min[0] = arr[i][j];
                }
                //Phan tu duong be nhat
                if (arr[i][j] > 0 && flag2 == true) {
                    max_min[1] = arr[i][j];
                    flag2 = false;
                }
                if (arr[i][j] > 0 && arr[i][j] < max_min[1]) {
                    max_min[1] = arr[i][j];
                }
            }
        }
        return max_min;
    }

    public static int demPhanTuDuong(int[][] arr) {
        int dem = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = i; j < arr[i].length; j++) {
                if(arr[i][j] > 0)
                    dem++;
            }
        }
        return dem;
    }
    public static int demSoAm(int[][] arr){//Dem so am chia het cho 2 va 3
        int dem = 0;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if(arr[i][j] < 0 && (arr[i][j] % 2 == 0) && (arr[i][j] % 3 == 0))
                    dem++;
            }
        }
        return dem;
    }
}
