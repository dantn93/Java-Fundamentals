/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai1 {

    /**
     * @param args the command line arguments
     */
    final static double[] M10 = new double[]{10000, 50};
    final static double[] M25 = new double[]{25000, 150};
    final static double[] M50 = new double[]{50000, 500};
    final static double[] M120 = new double[]{120000, 1.5 * 1024};
    final static double MAX = 70000;
    final static double MAX100 = 10000;
    final static double MAX200 = 200000;
    final static double MAXS = 50000;
    final static double vgM0 = 1.5;//Cuoc vuot goi M0
    final static double vgM = 0.5;//Cuoc vuot goi M10-M120

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap ten goi cuoc: ");
            String tenGoi = input.readLine();

            //=== Kiem tra ten goi cuoc hop le ===//
            while (true) {
                if (!ktTenGoi(tenGoi)) {
                    System.out.print("Ten goi sai! Xin hay nhap lai: ");
                    tenGoi = input.readLine();
                } else {
                    break;
                }
            }

            //=== Nhap dung luong da su dung ===//
            System.out.print("Nhap dung luong da su dung(Kb): ");
            double dungLuong = Double.parseDouble(input.readLine());
            double tienCuoc = traTienCuoc(tenGoi, dungLuong);
            System.out.println("Tien phai trai: "+String.format("%.2f", tienCuoc)+" (VND)");
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static boolean ktTenGoi(String tenGoi) {
        boolean flag = false;
        switch (tenGoi.toUpperCase()) {
            case "M0":
            case "M10":
            case "M25":
            case "M50":
            case "M120":
            case "MAX":
            case "MAX100":
            case "MAX200":
            case "MAXS":
                return true;
        }
        return false;
    }

    public static double traTienCuoc(String tenGoi, double dungLuong) {
        switch (tenGoi.toUpperCase()) {
            case "M0":
                return dungLuong * vgM0;

            case "M10":
                if (dungLuong <= M10[1] * 1024) {
                    return M10[0];
                } else {
                    return M10[0] + (dungLuong - M10[1] * 1024) * vgM;
                }
            case "M25":
                if (dungLuong <= M25[1] * 1024) {
                    return M25[0];
                } else {
                    return M25[0] + (dungLuong - M25[1] * 1024) * vgM;
                }
            case "M50":
                if (dungLuong <= M50[1] * 1024) {
                    return M50[0];
                } else {
                    return M50[0] + (dungLuong - M50[1] * 1024) * vgM;
                }
            case "M120":
                if (dungLuong <= M120[1] * 1024) {
                    return M120[0];
                } else {
                    return M120[0] + (dungLuong - M120[1] * 1024) * vgM;
                }
            case "MAX":
                return MAX;
            case "MAX100":
                return MAX100;
            case "MAX200":
                return MAX200;
            case "MAXS":
                return MAXS;
        }
        return 0;
    }
}
