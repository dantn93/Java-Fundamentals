/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class Bai4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap n: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //=== Tao mang String co n phan tu ===//
            String[] arr = new String[n];
            //=== Nhap mang String ===//
            System.out.println("=== Nhap mang String ===");
            for (int i = 0; i < arr.length; i++) {
                System.out.print("arr[" + i + "] = ");
                arr[i] = input.readLine();
            }
            //=== In thong tin mang ===//
            inThongTin(arr);
            //=== Phan tu co do dai lon nhat ===//
            System.out.println("=== Phan tu co do dai lon nhat ===");
            int[] vitri = phanTuDaiNhat(arr);
            for (int i = 0; i < vitri.length; i++) {
                if (vitri[i] == 1) {
                    System.out.println("[Vi tri]: " + i);
                    System.out.println("[Noi dung]: " + arr[i]);
                }

            }

            //=== Nhap vao mot chuoi, tim xem co ton tai trong arr khong ===//
            System.out.print("Nhap vao mot chuoi: ");
            String str = input.readLine();

            int[] vt = ktChuoi(arr, str);

            if (vt[vt.length - 1] == 1) {//Co ton tai
                System.out.println("Mang co gia tri giong voi chuoi da nhap. Vi tri: ");

                for (int i = 0; i < arr.length; i++) {
                    if (vt[i] == 1) {
                        System.out.println(i);
                    }
                }
            } else {
                System.out.println("Mang KHONG co gia tri giong voi chuoi da nhap.");
            }
            //=== Tao mang moi va sao chep vao mang nay ===//
            System.out.println("=== Tao mang moi va sao chep vao mang nay ===");
            String[] mangDich = saoChepMang(arr);
            inThongTin(mangDich);

            //=== Sap xep mang tang dan theo Alphabet ===//
            System.out.println("=== Sap xep mang tang dan theo Alphabet ===");

            String[] mangMoi = sapXepMangTangDan(arr);
            inThongTin(arr);
            inThongTin(mangMoi);

        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static void inThongTin(String[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println("[Noi dung]: " + arr[i] + "\t[Chieu dai]: " + arr[i].length());
        }
    }

    public static int[] phanTuDaiNhat(String[] arr) {
        int[] idx = new int[arr.length];
        for (int i = 0; i < idx.length; i++) {
            idx[i] = 0;
        }
        int length = arr[0].length();
        for (int i = 1; i < arr.length; i++) {
            if (arr[i].length() > length) {
                length = arr[i].length();
            }
        }
        //Kiem tra phan tu co do dai length
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].length() == length) {
                idx[i] = 1;
            }
        }
        return idx;
    }

    public static int[] ktChuoi(String[] arr, String c) {
        int[] flag = new int[arr.length + 1];
        for (int i = 0; i < flag.length; i++) {
            flag[i] = 0;
        }
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].equals(c)) {
                flag[i] = 1;
                flag[arr.length] = 1;
            }
        }
        return flag;
    }

    public static String[] saoChepMang(String[] src) {
        String[] dest = new String[src.length];
        for (int i = 0; i < src.length; i++) {
            dest[i] = src[i];
        }
        return dest;
    }

    public static String[] sapXepMangTangDan(String[] src) {
        String[] dest = new String[src.length];
        for (int i = 0; i < dest.length; i++) {
            dest[i] = src[i];
        }
        Arrays.sort(dest);
        return dest;
    }
}
