/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class Bai7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("1. So THAP PHAN sang so THAP LUC PHAN.");
            System.out.println("2. So THAP LUC PHAN sang so THAP PHAN.");
            System.out.println("Lua chon: ");
            int n = Integer.parseInt(input.readLine());
            //Kiem tra nhap sai
            while (true) {
                boolean flag = true;
                if (n == 1 || n == 2) {
                    flag = false;
                }
                if (flag == false) {
                    break;
                }
                System.out.println("Nhap sai! Hay nhap lai: ");
                n = Integer.parseInt(input.readLine());
            }

            //===Doi THAP PHAN sang THAP LUC PHAN===//
            
            if (n == 1) {
                System.out.println("===Doi THAP PHAN sang THAP LUC PHAN===");
                //===Nhap so THAP PHAN can doi===//
                System.out.print("Nhap so THAP PHAN can doi: ");
                String stp = input.readLine();
                while (true) {
                    Pattern pattern = Pattern.compile("^[0-9]+$");
                    Matcher m = pattern.matcher(stp);
                    if (!m.find()) {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        stp = input.readLine();
                    }
                    break;
                }
                String c = doiTPsangTLP(stp);
                System.out.println("So thap luc phan: "+c + "\n");
            }
            if (n == 2) {
                //===Nhap so THAP LUC PHAN can doi===//
                System.out.println("===Doi THAP LUC PHAN sang THAP PHAN===");
                System.out.print("Nhap so THAP LUC PHAN can doi: ");
                String stlp = input.readLine();
                while (true) {
                    Pattern pattern = Pattern.compile("^[0-9a-fA-F]+$");
                    Matcher m = pattern.matcher(stlp);

                    if (!m.find()) {
                        System.out.print("Nhap sai! Hay nhap lai: ");
                        stlp = input.readLine();
                    }
                    break;
                }
                System.out.println("So thap phan: "+doiTLPsangTP(stlp));
            }

        } catch (Exception ex) {
            System.out.println("Loi: Nhap khong dung dinh dang");
        }
    }

    public static String deQuy(int n, String c) {
        int d = n / 16;
        String chuoi = "";
        if (d != 0) {
            chuoi += deQuy(d, c);
        }
        switch (n % 16) {
            case 10:
                return chuoi + "A";
            case 11:
                return chuoi + "B";
            case 12:
                return chuoi + "C";
            case 13:
                return chuoi + "D";
            case 14:
                return chuoi + "E";
            case 15:
                return chuoi + "F";
            default:
                String t = "";
                t += "" + (n % 16);
                return chuoi + t;
        }
    }

    public static String doiTPsangTLP(String num) {
        System.out.print("So thap luc phan: ");
        String c = "";
        c += deQuy(Integer.parseInt(num), c);
        return c;
    }

    public static int doiTLPsangTP(String num) {
        int soThapPhan = 0;
        num = num.toUpperCase();
        for (int i = 0; i < num.length(); i++) {
            char c = num.charAt(num.length() - 1 - i);
            switch (c) {
                case 'A':
                    soThapPhan += (int)10 * (int)Math.pow(16, i);
                    break;
                case 'B':
                    soThapPhan += (int)11 * (int)Math.pow(16, i);
                    break;
                case 'C':
                    soThapPhan += (int)12 * (int)Math.pow(16, i);
                    break;
                case 'D':
                    soThapPhan += (int)13 * (int)Math.pow(16, i);
                    break;
                case 'E':
                    soThapPhan += (int)14 * (int)Math.pow(16, i);
                    break;
                case 'F':
                    soThapPhan += (int)15 * (int)Math.pow(16, i);
                    break;
                default:
                    soThapPhan += (int)(Integer.parseInt(c + "")) * (int)Math.pow(16, i);
            }
        }
        return soThapPhan;
    }
}
