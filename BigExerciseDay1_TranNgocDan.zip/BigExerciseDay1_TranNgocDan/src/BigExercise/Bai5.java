/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap n: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            //=== Tao mang mot chieu ===//
            System.out.println("=== Tao mang mot chieu ===");
            int[] arr = phatSinhNgauNhien(n);
            inMang(arr);

            //=== Tao ma trang vuong kieu chuoi ===//
            System.out.println("=== Tao ma trang vuong kieu chuoi ===");
            String[][] matran = ganGiaTri(arr);
            inMaTran(matran);
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static int[] phatSinhNgauNhien(int n) {
        Random rd = new Random();
        int[] arr = new int[n];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rd.nextInt(n);
        }
        return arr;
    }

    public static void inMang(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println("arr[" + i + "] = " + arr[i]);
        }
    }

    public static String[][] ganGiaTri(int[] arr) {
        String[][] dest = new String[arr.length][arr.length];
        for (int i = 0; i < dest.length; i++) {
            for (int j = 0; j < dest[i].length; j++) {
                dest[i][j] = "*";
            }
        }
        for (int i = 0; i < dest.length; i++) {
            dest[i][arr[i]] = "Q";
        }
        
        
        return dest;
    }
    
    public static void inMaTran(String[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println("");
        }
    }

}
