/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BigExercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class Bai6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("===Bang cuu chuong===");
            System.out.print("Tu: ");
            int n = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (n <= 0) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    n = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            System.out.print("Den: ");
            int m = Integer.parseInt(input.readLine());
            //===Kiem tra nhap dung===//
            while (true) {
                if (m >= 10) {
                    System.out.print("Nhap sai! Hay nhap lai: ");
                    m = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }

            if (n > m) {
                int temp = n;
                n = m;
                m = temp;
            }
            //=== Tao mang 2 chieu de chua TOAN BO bang cuu chuong===//
            int soLuong = m - n + 1;
            int[][] arr = dienVaoBCC(n, m);
            //inMaTran(arr);
            //=== In ra man hinh ===//
            System.out.println("=== Bang Cuu Chuong ===");
            System.out.print("Cot|\t");
            for (int i = n; i <= m; i++) {
                System.out.print(i + "\t");
            }
            System.out.println("\nCuu chuong\n------------------------------------");
            for (int i = 0; i < arr.length; i++) {
                System.out.print(arr[i][0]+"|\t");
                for (int j = 0; j < arr[i].length; j++) {
                    System.out.print(arr[i][j]+"\t");
                }
                System.out.println("");
            }

        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }

    }

    public static int[][] dienVaoBCC(int n, int m) {
        int coSo = n;
        int[][] arr = new int[m - n + 1][9];
        for (int i = 0; i < (m - n + 1); i++) {
            for (int j = 0; j < 9; j++) {
                arr[i][j] = coSo * (j + 1);
            }
            coSo++;
        }
        return arr;
    }

    public static void inMaTran(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println("");
        }
    }

}
