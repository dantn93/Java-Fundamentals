/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

/**
 *
 * @author hocvien
 */
public class timKiemTrongMang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = new int[n];
        System.out.println("Nhap gia tri cho cac phan tu trong mang: ");
        for (int i = 0; i < n; i++) {
            System.out.print("Phan tu thu " + i + ": ");
            arr[i] = Integer.parseInt(input.readLine());
        }
        System.out.print("Nhap x: ");
        int x = Integer.parseInt(input.readLine());
        //Mang da nhap
        System.out.println("Mang da nhap: ");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i]);
        }
        System.out.println("");
        //Search
        boolean flag = false;
        for (int i = 0; i < n; i++) {
            if (x == arr[i]) {
                System.out.println(x + " xuat hien trong mang tai vi tri " + i);
                flag = true;
            }
        }
        if (flag == false) {
            System.out.println(x + " khong nam trong mang a");
        }
        //So sanh
        boolean nhoHon = false;
        String s = "";
        
        for (int i = 0; i < n; i++) {
            if (x <= arr[i]) {
                nhoHon = true;
                if (x < arr[i]) {
                    s += Integer.toString(arr[i]) + ", ";
                }
            }
        }
        if (nhoHon == true) {
            System.out.println(x + " khong lon hon tat ca cac so trong mang a");
        }
        System.out.println("Ta ca cac so lon hon " + x + " la: ");
        for (int i = 0; i < s.length() - 2; i++) {
            System.out.print(s.charAt(i));
        }
        System.out.println("");
        
    }
}
