/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author hocvien
 */
public class xuLyMangHaiChieu {

    /**
     * @param args the command line arguments
     */
    public static void xuatMang(int n, int m, int[][] arr) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.println("a[" + i + "][" + j + "] = " + arr[i][j]);
            }
        }
    }

    public static int demSoChan(int n, int m, int[][] arr) {
        int chan = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] % 2 == 0) {
                    chan++;
                }
            }
        }
        return chan;
    }

    public static int demSoLe(int n, int m, int[][] arr) {
        int le = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] % 2 == 1) {
                    le++;
                }
            }
        }
        return le;
    }

    public static float trungBinhChan(int n, int m, int[][] arr) {
        int count = 0;
        float sum = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] % 2 == 0) {
                    count++;
                    sum += arr[i][j];
                }
            }
        }
        return (float) (sum / count);
    }

    public static float trungBinhLe(int n, int m, int[][] arr) {
        int count = 0;
        float sum = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (arr[i][j] % 2 == 1) {
                    count++;
                    sum += arr[i][j];
                }
            }
        }
        return (float) (sum / count);
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap so dong n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.print("Nhap so cot m: ");
        int m = Integer.parseInt(input.readLine());
        int[][] arr = new int[n][m];

        //Nhap cac phan tu cau man
        System.out.println("Nhap cac phan tu cua mang: ");
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                arr[i][j] = Integer.parseInt(input.readLine());
            }
        }
        //Xuat mang
        xuatMang(n, m, arr);
        //Dem so phan tu chan, le
        System.out.println("So phan tu chan: " + demSoChan(n, m, arr));
        System.out.println("So phan tu le: " + demSoLe(n, m, arr));
        //Trung binh cong cac phan tu chan
        System.out.println("Trung binh cac so chan: " + trungBinhChan(n, m, arr));
        //Trung binh cong cac phan tu le
        System.out.println("Trung binh cac so le: " + trungBinhLe(n, m, arr));
        //Tim phan tu lon nhat, nho nhat
        int i_lonNhat = 0;
        int j_lonNhat = 0;
        int i_beNhat = 0;
        int j_beNhat = 0;
        int soLonNhat = arr[0][0];
        int soBeNhat = arr[0][0];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (soLonNhat < arr[i][j]) {
                    soLonNhat = arr[i][j];
                    i_lonNhat = i;
                    j_lonNhat = j;
                }
                if (soBeNhat > arr[i][j]) {
                    soBeNhat = arr[i][j];
                    i_beNhat = i;
                    j_beNhat = j;
                }
            }
        }
        System.out.println("Phan tu lon nhat la a[" + i_lonNhat + "][" + j_lonNhat + "] = " + soLonNhat);
        System.out.println("Phan tu be nhat la a[" + i_beNhat + "][" + j_beNhat + "] = " + soBeNhat);
        //Phan tu co so lan xuat hien nhieu nhat trong mang
        //Dem so luong phan tu phan biet.
        HashMap phanTuPhanBiet = new HashMap();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (phanTuPhanBiet.get(arr[i][j]) == null) {
                    phanTuPhanBiet.put(arr[i][j], 1);
                } else {
                    phanTuPhanBiet.put(arr[i][j], (int) phanTuPhanBiet.get(arr[i][j]) + 1);
                }
            }
        }
        //so lan xuat hien lon nhat cua 1 phan tu nao do
        int max = 0;
        int soLanXuatHien = 0;
        Set<Map.Entry<Integer, Integer>> entrySet = phanTuPhanBiet.entrySet();
        for (Map.Entry<Integer, Integer> entry : entrySet) {
            if (max < (int) entry.getValue()) {
                max = (int) entry.getValue();
            }
        }
        
        //Kiem tra xem nhung phan tu nao co cung so lan xuat hien lon nhat
        ArrayList so = new ArrayList();
        entrySet = phanTuPhanBiet.entrySet();
        for (Map.Entry<Integer, Integer> entry : entrySet) {
            if (max == (int) entry.getValue()) {
                so.add((int) entry.getKey());
            }
        }
       
        //In ra so xuat hien nhieu nhat
        for (int ix = 0; ix < so.size(); ix++) {
            System.out.println("So xuat hien nhieu nhat la: " + so.get(ix) + " co " + phanTuPhanBiet.get((int)so.get(ix)) + " lan xuat hien");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    if((int)so.get(ix) == arr[i][j])
                        System.out.println("xuat hien tai vi tri [" + i + "][" + j + "]");
                }
            }
        }
        //Kiem tra ma tran co phan tu am hay khong
        int c1 = 0;
        for (int i = 0; i < n; i++) {
            boolean count = false;
            for (int j = 0; j < m; j++) {
                if (arr[i][j] < 0) {
                    System.out.println("Ma tran co phan tu am");
                    count = true;
                    break;
                }
                if (count == true) {
                    break;
                }
                c1++;
            }
        }
        if (c1 == n * m) {
            System.out.println("Ma tran KHONG co phan tu am");
        }
        
    }
}
