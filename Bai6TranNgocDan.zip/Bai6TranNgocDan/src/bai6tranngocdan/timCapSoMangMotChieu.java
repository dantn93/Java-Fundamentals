/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6tranngocdan;

/**
 *
 * @author hocvien
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class timCapSoMangMotChieu {

    /**
     * @param args the command line arguments
     */
    public static void xuatMang(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = new int[n];
        System.out.println("Nhap gia tri cho cac phan tu trong mang: ");
        for (int i = 0; i < n; i++) {
            System.out.print("Phan tu thu " + i + ": ");
            arr[i] = Integer.parseInt(input.readLine());
        }
        //Xuat mang a
        xuatMang(arr);
        //
        System.out.println("Cap so co quan he chia het:");
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if ((arr[i] % arr[j] == 0) || (arr[j] % arr[i] == 0)) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }

        System.out.println("Cap so co quan he gap doi:");
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (((arr[i] % arr[j] == 0) && (arr[i] / arr[j] == 2))
                        || ((arr[j] % arr[i] == 0) && arr[j] / arr[i] == 2)) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }

        System.out.println("Cap so co quan he tong bang 8:");
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] + arr[j] == 8) {
                    System.out.println(arr[i] + " & " + arr[j]);
                }
            }
        }
    }

}
