/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai6tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class xuLyMangNgauNhien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = new int[n];
        //Tao gia tri ngau nhien
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n);
        }
        //Xuat gia tri ngau nhien
        int sum = 0;
        System.out.println("Mang ngau nhien:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i]);
            sum += arr[i];
        }
        System.out.println("\nTong: "+sum);
    }

}
