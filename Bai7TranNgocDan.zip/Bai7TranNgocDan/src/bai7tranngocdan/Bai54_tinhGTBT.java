/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class Bai54_tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());

        //Tong cac so nguyen to nho hon hay bang n
        System.out.println("Ket qua A = " + tinhA(n));
        System.out.println("Ket qua B = " + tinhB(n));
        System.out.println("Ket qua C = " + tinhC(n));
        System.out.println("Ket qua D = " + tinhD(n));
        System.out.println("Ket qua D = " + tinhE(n));

    }

    public static int tinhA(int n) {
        int A = 0;
        for (int i = 1; i <= n; i += 2) {
            A += i;
        }
        return A;
    }

    public static int tinhB(int n) {
        int B = 0;
        for (int i = 0; i <= n; i += 2) {
            B += i;
        }
        return B;
    }

    public static int tinhC(int n) {
        int C = 1;
        for (int i = 1; i <= n; i++) {
            C *= i;
        }
        return C;
    }

    public static int tinhD(int n) {
        int D = 1;
        for (int i = 1; i <= n; i++) {
            if (i % 3 == 0) {
                D *= i;
            }
        }
        return D;

    }

    public static int tinhE(int n) {
        int E = 0;
        for (int i = 2; i <= n; i++) {
            boolean flag = false;
            int m = i / 2;
            for (int j = 2; j <= m; j++) {
                if (i % j == 0) {
                    flag = true;
                    break;
                }
            }
            if (flag == false) {
                E += i;
            }
        }
        return E;
    }
}
