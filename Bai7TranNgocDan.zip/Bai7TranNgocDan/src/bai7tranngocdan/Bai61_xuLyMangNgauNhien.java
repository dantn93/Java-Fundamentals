/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

/**
 *
 * @author hocvien
 */
public class Bai61_xuLyMangNgauNhien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int[] arr = phatSinhMangNN(n);
        //Xuat mang
        xuatMang(arr);
        int tong = tinhTong(arr);
        System.out.println("Tong: " + tong);
    }

    public static int[] phatSinhMangNN(int n) {
        int[] arr = new int[n];
        //Tao gia tri ngau nhien
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            arr[i] = random.nextInt(n);
        }
        return arr;
    }

    public static void xuatMang(int... arr) {
        System.out.println("Xuat mang: ");
        for (int el : arr) {
            System.out.println(el);
        }
    }

    public static int tinhTong(int... arr) {
        int tong = 0;
        for (int el : arr) {
            tong += el;
        }
        return tong;
    }

}
