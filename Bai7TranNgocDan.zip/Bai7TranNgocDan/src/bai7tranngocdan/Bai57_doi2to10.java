/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai7tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

/**
 *
 * @author hocvien
 */
public class Bai57_doi2to10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap so nhi phan n: ");
        Integer n = Integer.parseInt(input.readLine());
        System.out.println("So thap phan: "+doi2_10(n.toString()));
    }
    
    public static int doi2_10(String s){
        int soThapPhan = 0;
        for (int i = s.length()-1; i >= 0; i--) {
            soThapPhan += Integer.parseInt(s.charAt(i)+"")*pow(2,s.length()-1-i);
        }
        return soThapPhan;
    }

}
