/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13tranngocdan;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;
import sun.util.locale.StringTokenIterator;

/**
 *
 * @author hocvien
 */
public class inNgayThangNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Kiem tra ngay hien tai
        SimpleDateFormat dF = new SimpleDateFormat("dd-MM-yyyy");
        
        LocalDate d = LocalDate.now();
        System.out.println("Ngay trong tuan: " + d.getDayOfWeek());
        
        Calendar cldr = Calendar.getInstance();
        System.out.println("Ngay hien tai: " + dF.format(cldr.getTime()));
        System.out.println("Tuan trong nam: " + cldr.get(Calendar.WEEK_OF_YEAR));
        
        Calendar cl = (Calendar)cldr.clone();
        cl.add(Calendar.WEEK_OF_YEAR, 1);
        System.out.println("Mot tuan sau la ngay: "+dF.format(cl.getTime()));
    }
}
