/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai13tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class thongBaoNgaySinhNhat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap ngay thang nam sinh (dd/MM/yyyy): ");
            String ngaySinh = input.readLine();
            Pattern pt = Pattern.compile("^([0-9]+){1,2}/([0-9]+){1,2}/([0-9]+){1,}$");
            Matcher m = pt.matcher(ngaySinh);
            if (m.matches()) {
                //Lay ngay hien tai
                //Calendar cldr = Calendar.getInstance();
                StringTokenizer tk = new StringTokenizer(ngaySinh, "/");
                int ngay = Integer.parseInt(tk.nextToken());
                int thang = Integer.parseInt(tk.nextToken());
                int nam = Integer.parseInt(tk.nextToken());
                //Kiem tra ngay sinh nhap vao hop le
                if (ktNgayThangNam(ngay, thang, nam)) {
                    LocalDate homNay = LocalDate.now();
                    LocalDate sinhNhat = LocalDate.of(homNay.getYear(), thang, ngay);
                    Period conlai = Period.between(sinhNhat, homNay);//Khoang cach giua hom nay va sinh nhat CON bao nhieu ngay...
                    
                    if (conlai.getMonths() == 0 && conlai.getDays() == 0) {
                        System.out.println("Chuc mung sinh nhat!");
                    } else if ((conlai.getMonths() == 0 && conlai.getDays() < 0) || conlai.getMonths() < 0) {
                        System.out.println("Vui long doi them...");
                    } else {
                        System.out.println("Hen sinh nhat nam sau...");
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static boolean ktNgayThangNam(int ngay, int thang, int nam) {
        if (ngay <= 0) {
            throw new ArithmeticException("Ngay <=  0!");
        }
        if (thang <= 0) {
            throw new ArithmeticException("Ngay <=  0!");
        }
        if (nam <= 0) {
            throw new ArithmeticException("Ngay <=  0!");
        }
        int NGAYTRONGTHANG2 = 0;
        if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0)) {
            NGAYTRONGTHANG2 = 29;
        } else {
            NGAYTRONGTHANG2 = 28;
        }
        switch (thang) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (ngay <= 0 || ngay > 31) {
                    return false;
                }
            case 2:
                if (ngay <= 0 || ngay > NGAYTRONGTHANG2) {
                    return false;
                }

            case 4:
            case 6:
            case 9:
            case 11:
                if (ngay <= 0 || ngay > 30) {
                    return false;
                }
        }
        return true;
    }
}
