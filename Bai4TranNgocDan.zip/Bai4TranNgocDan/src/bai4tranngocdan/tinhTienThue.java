/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhTienThue {
final static double THUEBAC1=0.05;
final static double THUEBAC2=0.1;
final static double THUEBAC3=0.15;
final static double THUEBAC4=0.2;
final static double THUEBAC5=0.25;
final static double THUEBAC6=0.3;
final static double THUEBAC7=0.35;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Tong thu nhap trong nam (trieu): ");
        double thuNhap = Double.parseDouble(input.readLine());
        //Kiem tra dieu kien nhap
        while(thuNhap < 0)
        {
            System.out.print("Nhap lai: ");
            thuNhap = Double.parseDouble(input.readLine());
        }
        System.out.print("So nguoi phu thuoc (nguoi): ");
        int soNguoiPT = Integer.parseInt(input.readLine());
        while(soNguoiPT < 0)
        {
            System.out.print("Nhap lai: ");
            soNguoiPT = Integer.parseInt(input.readLine());
        }
        //Tien giam tru
        double tienGiam = (double)((9 + soNguoiPT*3.6)*12);
        double tongTien = thuNhap - tienGiam;
        double thue = 0;
        if(tongTien > 0 && tongTien <= 60)
            thue = (double)(tongTien*THUEBAC1);
        else if(tongTien > 60 && tongTien <= 120)
            thue = (double)((tongTien-60)*THUEBAC2+60*THUEBAC1);
        else if(tongTien > 120 && tongTien <= 216)
            thue = (double)((tongTien-120)*THUEBAC3+60*THUEBAC2+60*THUEBAC1);
        else if(tongTien > 216 && tongTien <= 384)
            thue = (double)((tongTien-216)*THUEBAC4+96*THUEBAC3+60*THUEBAC2+60*THUEBAC1);
        else if(tongTien > 384 && tongTien <= 623)
            thue = (double)((tongTien-384)*THUEBAC5+168*THUEBAC4+96*THUEBAC3+60*THUEBAC2+60*THUEBAC1);
        else if(tongTien > 623 && tongTien <= 960)
            thue = (double)((tongTien-624)*THUEBAC6+240*THUEBAC5+168*THUEBAC4+96*THUEBAC3+60*THUEBAC2+60*THUEBAC1);
        else
            thue = (double)((tongTien-960)*THUEBAC7+336*THUEBAC6+240*THUEBAC5+168*THUEBAC4+96*THUEBAC3+60*THUEBAC2+60*THUEBAC1);
        System.out.println("Thue phai nop: "+String.format("%.2f", thue)+" trieu");
        
        
    }
    
}
