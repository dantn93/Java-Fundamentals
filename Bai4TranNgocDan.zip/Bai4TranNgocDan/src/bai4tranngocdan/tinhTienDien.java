/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhTienDien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap so kw: ");
        float kw = Float.parseFloat(input.readLine());
        double thanhTien = 0;
        if(kw > 0 && kw <= 50)
        {
            thanhTien = kw*1388;
        }else if(kw > 50 && kw <= 100)
        {
            thanhTien = 1433*(kw - 50) + 50*1388;
        }else if(kw > 100 && kw <= 200)
        {
            thanhTien = 1660*(kw - 100) + 1433*50 + 50*1388;
        }else if(kw > 200 && kw <= 300)
        {
            thanhTien = 2082*(kw - 200) + 1660*100 + 1433*50 + 50*1388;
           
        }else if(kw > 300 && kw <= 400)
        {
            thanhTien = 2324*(kw - 300) + 2082*100 + 1660*100 + 1433*50+1388*50;
        }else if(kw > 400)
        {
            thanhTien = 2399*(kw - 400) + 2324*100 + 2082*100 + 1660*100 + 1433*50+1388*50;
        }
        
        System.out.println("Thanh tien: "+String.format("%.2f", thanhTien));
        
           
    }
    
}

