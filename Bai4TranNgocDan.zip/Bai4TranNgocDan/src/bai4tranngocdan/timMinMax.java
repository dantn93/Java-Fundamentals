/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class timMinMax {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap a: ");
        float a = Float.parseFloat(input.readLine());
        System.out.print("Nhap b: ");
        float b = Float.parseFloat(input.readLine());
        System.out.print("Nhap c: ");
        float c = Float.parseFloat(input.readLine());
        System.out.print("Nhap d: ");
        float d = Float.parseFloat(input.readLine());
        float min = a;
        float max = a;
        
        if(max < b)
            max = b;
        if(max < c)
            max = c;
        if(max < d) 
            max = d;
        
        if(min > b)
            min = b;
        if(min > c)
            min = c;
        if(min > d) 
            min = d;
        
        System.out.println("Gia tri a, b, c, d: "
                +String.format("%.2f", a)
                +", "+
                String.format("%.2f", b)
                +", "+
                String.format("%.2f", c)
                +", "+
                String.format("%.2f", d));
        
        System.out.println("So lon nhat: " + String.format("%.2f", max));
        System.out.println("So nho nhat: " + String.format("%.2f", min));
    }
    
}
