/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class doiNhietDo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        
        String doDo = "";
        boolean flag = true;
        while(flag){
            switch(doDo)
            {
                case "F": 
                case "f":
                    System.out.println("Ban muon doi nhiet do tu Fahrenheit => Cecius");
                    System.out.print("Nhap nhiet do: ");
                    float f = Float.parseFloat(input.readLine());
                    float c = (float)((5*(f - 32))/9);
                    System.out.println(f+" F = "+c+" C");
                    break;
                case "C":
                case "c":
                    System.out.println("Ban muon doi nhiet do tu Cecius => Fahrenheit");
                    System.out.print("Nhap nhiet do: ");
                    c = Float.parseFloat(input.readLine());
                    f = (float)((c*9)/5+32);
                    System.out.println(c+" C = "+f+" F");
                    break;
            }
            if(flag == true)
            {
                System.out.print("Nhap do do Fahrenheit hoac Cecius [F/C]: ");
                doDo = input.readLine();
            }
        }
    }
    
}
