/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhTienThuePhong {
final static float LOAI1 = 1260000f;
final static float LOAI2 = 1550000f;
final static float LOAI3 = 1830000f;
final static float LOAI4 = 1830000f;
final static float LOAI5 = 2120000f;
final static float LOAI6 = 2120000f;
final static float LOAI7 = 2540000f;
final static float LOAI8 = 4800000f;


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Loai phong: ");
        int loaiPhong = Integer.parseInt(input.readLine());
        System.out.print("Nhap so dem: ");
        float thanhtien = 0;
        int soDem = Integer.parseInt(input.readLine());
        
        switch(loaiPhong){
                case 1:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI1;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI1)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI1)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 2:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI2;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI2)*soDem;
                        
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI2)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 3:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI3;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI3)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI3)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 4:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI4;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI4)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI4)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 5:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI5;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI5)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI5)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 6:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI6;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI6)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI6)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 7:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI7;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI7)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI7)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;
                case 8:
                    if(soDem == 1)
                    {
                        thanhtien = LOAI8;
                        
                    }else if(soDem >= 2 && soDem <=3)
                    {
                        thanhtien = (float) (0.75 * LOAI8)*soDem;
                        
                    
                    }else if(soDem >= 4)
                    {
                        thanhtien = (float) (0.7 * LOAI8)*soDem;
                    }
                    System.out.println("Thanh tien: "+String.format("%.2f", thanhtien));
                    break;        
        }
     
        
    }
}
