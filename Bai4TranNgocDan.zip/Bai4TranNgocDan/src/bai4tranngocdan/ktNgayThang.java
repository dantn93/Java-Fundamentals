/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class ktNgayThang {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap ngay: ");
        int ngay = Integer.parseInt(input.readLine());
        System.out.print("Nhap thang: ");
        int thang = Integer.parseInt(input.readLine());
        System.out.print("Nhap nam: ");
        int nam = Integer.parseInt(input.readLine());
        int NGAYTRONGTHANG2 = 0;
        if(nam % 400 == 0 ||(nam % 4 == 0 && nam % 100 != 0))
            NGAYTRONGTHANG2 = 29;
        else
            NGAYTRONGTHANG2 = 28;
        int ngayHomsau = 0;
        int ngayHomtruoc = 0;
        while(thang < 1 || thang > 12)
        {
            System.out.println("Thang khong hop le! Nhap lai: ");
            thang = Integer.parseInt(input.readLine());
        }
            
        switch(thang)
        {
            case 1:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co 31 ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 2:
                while(ngay <= 0 && ngay > NGAYTRONGTHANG2)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+NGAYTRONGTHANG2 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == NGAYTRONGTHANG2)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 3:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+ 31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 29;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 4:
                while(ngay <= 0 && ngay > 30)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+ 30 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 30)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 5:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+ 31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 30;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 6:
                while(ngay <= 0 && ngay > 30)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+ 30 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 30)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 7:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 30;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 8:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 9:
                while(ngay <= 0 && ngay > 30)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+30 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 30)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 10:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 30;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 11:
                while(ngay <= 0 && ngay > 30)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+30 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 31;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 30)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
            case 12:
                while(ngay <= 0 && ngay > 31)
                {
                    System.out.print("Ngay khong hop le! Nhap lai: ");
                    ngay = Integer.parseInt(input.readLine());
                }
                //Thang nhap co bao nhieu ngay
                System.out.println("Thang "+thang+ " co "+31 +" ngay");
                
                //Ngay hom truoc
                if(ngay == 1)
                    ngayHomtruoc = 30;
                else
                    ngayHomtruoc = ngay - 1;
                System.out.println("Ngay hom truoc: "+ngayHomtruoc);
                //Ngay hom sau
                if(ngay == 31)
                    ngayHomsau = 1;
                else
                    ngayHomsau = ngay + 1;
                System.out.println("Ngay hom sau: "+ngayHomsau);
                break;
                
                
        }
                
        
    }
    
}
