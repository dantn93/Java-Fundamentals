/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai4tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class tinhCuocTaxi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap loai xe: ");
        int loaiXe = Integer.parseInt(input.readLine());
        System.out.print("Nhap so km: ");
        float km = Float.parseFloat(input.readLine());
        if(loaiXe == 4)
        {
            if(km > 0 && km <= 0.8)
                System.out.println("Thanh tien: 11000");
            else if(km > 0.8 && km <= 30)
            {   
                double thanhTien = (double)(16500*(km-0.8) + 11000);
                System.out.println("Thanh tien: "+String.format("%.2f", thanhTien));
            }
            else if(km > 30)
            {
                double thanhTien = (double)(12400*(km-30-0.8)+16500*(30-0.8) + 11000);
                System.out.println("Thanh tien: "+String.format("%.2f", thanhTien));

            }
        }
        else if(loaiXe == 7)
        {
            if(km > 0 && km <= 0.8)
                System.out.println("Thanh tien: 11000");
            else if(km > 0.8 && km <= 30)
            {   
                double thanhTien = (double)(17000*(km - 0.8) + 11000);
                System.out.println("Thanh tien: "+String.format("%.2f", thanhTien));
            }
            else if(km > 30)
            {
                double thanhTien = (double)(14400*(km-30-0.8)+17000*(30 - 0.8) + 11000);
                System.out.println("Thanh tien: "+String.format("%.2f", thanhTien));

            }
    
        }
    }
}
        

