/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_for;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int A = 0;
        int B = 0;
        int C = 1;
        int D = 1;
        for (int i = 1; i <= n; i += 2) {
            A += i;
        }
        for (int i = 0; i <= n; i += 2) {
            B += i;
        }
        for (int i = 1; i <= n; i++) {
            C *= i;
        }
        for (int i = 1; i <= n; i++) {
            if (i % 3 == 0) {
                D *= i;
            }
        }

        //Tong cac so nguyen to nho hon hay bang n
        int E = 0;
        for (int i = 2; i <= n; i++) {
            boolean flag = false;
            int m = i / 2;
            for (int j = 2; j <= m; j++) {
                if (i % j == 0) {
                    flag = true;
                    break;
                }
            }
            if(flag == false)
            {
                E += i;
            }
        }
        System.out.println("Ket qua A = " + A);
        System.out.println("Ket qua B = " + B);
        System.out.println("Ket qua C = " + C);
        System.out.println("Ket qua D = " + D);
        System.out.println("Ket qua E = " + E);

    }

}
