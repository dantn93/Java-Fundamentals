/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_for;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import static java.lang.Math.pow;

/**
 *
 * @author snow
 */
public class doi10to2 {

    /**
     * @param args the command line arguments
     */
    public static void chuyenDoi(int n) {
        if (n > 0) {
            chuyenDoi(n / 2);
            System.out.print(n % 2);
        }
    }

    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap so thap phan n: ");
        int n = Integer.parseInt(input.readLine());
        //So nguyen duong
        chuyenDoi(n);
        System.out.println("");
    }

}
