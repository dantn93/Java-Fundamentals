/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_for;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class tinhGiaiThua {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int a1 = 1;
        int a2 = 1;
        if (n % 2 == 0)//So chan
        {
            System.out.print(n+"! = ");
            for (int i = 1; i < n; i++) {
                a1 *= i;
                System.out.print(i+" x ");
            }
            System.out.print(n+" = "+a1*n+"\n");
            
            System.out.print(n+"!! = ");
            for (int i = 2; i < n; i += 2) {
                a2 *= i;
                System.out.print(i+" x ");
            }
            System.out.print(n+" = "+a2*n+"\n");
            
        } else {
            System.out.print(n+"! = ");
            for (int i = 1; i < n; i++) {
                a1 *= i;
                System.out.print(i+" x ");
            }
            System.out.print(n+" = "+a1*n+"\n");
            
            
            System.out.print(n+"!! = ");
            for (int i = 1; i < n; i += 2) {
                a2 *= i;
                System.out.print(i+" x ");
            }
            System.out.print(n+" = "+a2*n+"\n");
        }

    }

}
