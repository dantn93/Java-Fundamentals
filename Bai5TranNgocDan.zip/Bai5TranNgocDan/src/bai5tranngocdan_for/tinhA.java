/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_for;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class tinhA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        System.out.print("Nhap x: ");
        float x = Float.parseFloat(input.readLine());
        float A1 = 1;
        float A2 = 1;
        for (int i = 0; i < n; i++) {
            A1 *= (x * x + x + 1);
            A2 *= (x * x - x + 1);
        }
        System.out.println("S = (x * x + x + 1) mu "+n+" (x * x - x + 1) mu "+n+" = "+String.format("%.2f", A1+A2));
    }
    
}
