/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_while;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class bangCuuChuong {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("*******************************************************************");
        System.out.println("In bang cuu chuong");
        System.out.println("*******************************************************************");
        System.out.print("Tu so: ");
        int a = Integer.parseInt(input.readLine());
        System.out.print("Den so: ");
        int b = Integer.parseInt(input.readLine());
        System.out.println("--------------------------------------------------------------------");
        if (a <= b) {
            int i = 1;
            while (i <= 9) {
                for (int j = a; j <= b; j++) {
                    System.out.print(j + " x " + i + " = " + j * i + "\t");
                }
                System.out.print("\n");
                i++;
            }
        } else {
            System.out.println("a < b. Hay nhap lai.");
        }
    }

}
