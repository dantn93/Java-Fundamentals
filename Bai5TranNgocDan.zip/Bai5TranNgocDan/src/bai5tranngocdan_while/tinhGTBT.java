/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_while;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class tinhGTBT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap n: ");
        int n = Integer.parseInt(input.readLine());
        int A = 0;
        int B = 0;
        int C = 1;
        int D = 1;
        int i = 1;
        while (i <= n) {
            A += i;
            i += 2;
        }

        i = 0;
        while (i <= n) {
            B += i;
            i += 2;
        }

        i = 1;
        while (i <= n) {
            C *= i;
            i++;
        }

        i = 1;
        while (i <= n) {
            if (i % 3 == 0) {
                D *= i;
            }
            i++;
        }

        //Tong cac so nguyen to nho hon hay bang n
        int E = 0;
        i = 2;
        while (i <= n) {
            boolean flag = false;
            int m = i / 2;
            int j = 2;
            while (j <= m) {
                if (i % j == 0) {
                    flag = true;
                    break;
                }
                j++;
            }
            if (flag == false) {
                E += i;
            }
            i++;
        }
        System.out.println("Ket qua A = " + A);
        System.out.println("Ket qua B = " + B);
        System.out.println("Ket qua C = " + C);
        System.out.println("Ket qua D = " + D);
        System.out.println("Ket qua E = " + E);

    }

}
