/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai5tranngocdan_while;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class ktSoNT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Nhap x: ");
        int x = Integer.parseInt(input.readLine());
        if (x >= 2) {
            int m = x / 2;
            boolean flag = false;
            int i = 2;
            while (i <= m) {
                if (x % i == 0) {
                    flag = true;
                    break;
                }
                i++;
            }
            
            if (flag == true) {
                System.out.println(x + " KHONG phai so nguyen to!");
            } else {
                System.out.println(x + " la so nguyen to!");
            }
        } else {
            System.out.println(x + " KHONG phai so nguyen to!");
        }
    }

}
