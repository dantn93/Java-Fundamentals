/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class inMaTran {

    final static int MAX = 8;
    final static int MAX2 = 7;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            System.out.println("==Ma tran a==");
            inMaTranA(MAX);
            System.out.println("==Ma tran b==");
            inMaTranB(MAX);
            System.out.println("==Ma tran c==");
            inMaTranC(MAX);
            System.out.println("==Ma tran d==");
            inMaTranD(MAX);
            System.out.println("==Ma tran e==");
            inMaTranE(MAX);
            System.out.println("==Ma tran f==");
            inMaTranF(MAX);
            System.out.println("==Ma tran g==");
            inMaTranG(MAX);
            System.out.println("==Ma tran  h==");
            inMaTranH(MAX);
            System.out.println("==Ma tran  i==");
            inMaTranI(MAX);
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

    public static void inMaTranA(int MAX) {
        String s = "";
        for (int i = 1; i <= MAX; i++) {
            for (int j = 0; j < i; j++) {
                s += "# ";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranB(int MAX) {
        String s = "";
        for (int i = MAX - 1; i >= 0; i--) {
            for (int j = i; j >= 0; j--) {
                s += "# ";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranC(int MAX) {
        String s = "";
        boolean flag = true;
        for (int i = MAX - 1; i >= 0; i--) {
            flag = true;
            for (int j = i; j >= 0; j--) {
                if (flag == true) {
                    for (int k = 0; k < MAX - 1 - i; k++) {
                        s += "  ";
                    }
                    flag = false;
                }
                s += "# ";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranD(int MAX) {
        String s = "";
        boolean flag = true;
        for (int i = 1; i <= MAX; i++) {
            flag = true;
            for (int j = 0; j < i; j++) {
                if (flag == true) {
                    for (int k = MAX - 1 - i; k >= 0; k--) {
                        s += "  ";
                    }
                    flag = false;
                }
                s += "# ";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranE(int MAX) {
        String s = "";
        for (int i = 0; i < MAX; i++) {
            if (i == 0 || i == MAX - 1) {
                for (int k = 0; k < MAX; k++) {
                    s += "# ";
                }
            } else {
                s += "# ";
                for (int j = 0; j < MAX - 2; j++) {
                    s += "  ";
                }
                s += "# ";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranF(int MAX) {
        String s = "";
        for (int i = 0; i < MAX; i++) {
            if (i == 0 || i == MAX - 1) {
                for (int k = 0; k < MAX; k++) {
                    s += "# ";
                }
            } else {
                for (int k = 0; k < i; k++) {
                    s += "  ";
                }
                s += "#";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranG(int MAX) {
        String s = "";
        for (int i = 0; i < MAX; i++) {
            if (i == 0 || i == MAX - 1) {
                for (int k = 0; k < MAX; k++) {
                    s += "# ";
                }
            } else {
                for (int k = MAX - 2 - i; k >= 0; k--) {
                    s += "  ";
                }
                s += "#";
            }
            s += "\n";
        }
        System.out.println(s);
    }

    public static void inMaTranH(int MAX) {
        String s = "";
        int m = MAX2 / 2;
        for (int i = 0; i < MAX2; i++) {
            s += "# ";
        }
        s += "\n";
        for (int i = 1; i < m; i++) {
            for (int j = 0; j < i; j++) {
                s += "  ";
            }
            s += "# ";
            for (int j = 0; j < MAX2 - i * 2 - 2; j++) {
                s += "  ";
            }
            s += "#\n";
        }
        for (int i = 0; i < m; i++) {
            s += "  ";
        }
        s += "#\n";
        //Phan con lai

        for (int i = m - 1; i > 0; i--) {
            for (int j = i; j > 0; j--) {
                s += "  ";
            }
            s += "# ";
            for (int j = 0; j < MAX2 - i * 2 - 2; j++) {
                s += "  ";
            }
            s += "#\n";
        }
        for (int i = 0; i < MAX2; i++) {
            s += "# ";
        }
        System.out.println(s);
    }

    public static void inMaTranI(int MAX) {
        String s = "";
        for (int i = 0; i < MAX2; i++) {
            if (i == 0 || i == MAX2 - 1) {
                for (int j = 0; j < MAX2; j++) {
                    s += "# ";
                }
                s += "\n";
            } else {
                s += "# ";
                for (int j = 1; j < MAX2 - 1; j++) {
                    if (j == i || j == MAX2 - i - 1) {
                        s += "# ";
                    } else {
                        s += "  ";
                    }
                }
                s += "# \n";
            }
        }
        System.out.println(s);
    }
}
