/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class xuLyChuoiStringBuilder1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi sb: ");
            StringBuilder sb = new StringBuilder(input.readLine());
            //==Yeu cau1: Duyet va in tung ky tu trong chuoi sb==//
            System.out.println("==Duyet va in tung ky tu trong chuoi sb==");
            for (int i = 0; i < sb.length(); i++) {
                System.out.println("Ky tu sb[" + i + "]: " + sb.charAt(i));
            }

            //==Yeu cau2: Tim vi tri cua kt trong sb
            System.out.println("==Tim chuoi kt trong chuoi sb==");
            System.out.print("Nhap chuoi kt: ");
            StringBuilder kt = new StringBuilder(input.readLine());
            String temp = sb.toString();
            int vitri = 0;
            int vitriThat = 0;
            if (temp.indexOf(kt.toString()) >= 0) {
                while (true) {
                    vitri = temp.indexOf(kt.toString());
                    vitriThat += vitri;
                    System.out.println("Tim thay chuoi "+kt+" trong sb tai vi tri: " + vitriThat);
                    temp = temp.substring(vitri + kt.length());
                    System.out.println(temp);
                    vitriThat+=kt.length();
                    if(temp.equals(""))
                        break;
                }
            } else {
                System.out.println("KHONG tim thay");
            }

        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
