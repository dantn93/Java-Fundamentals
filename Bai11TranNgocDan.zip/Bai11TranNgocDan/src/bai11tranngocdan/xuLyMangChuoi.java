
import java.io.BufferedReader;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hocvien
 */
public class xuLyMangChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap so nguyen duong: ");
            int n = Integer.parseInt(input.readLine());
            while (n <= 0) {
                System.out.print("n > 0 !!!\nNhap lai: ");
                n = Integer.parseInt(input.readLine());
            }

            //==Yeu cau1: Nhap ten va kiem tra trong mang co ten do khong
            String[] mangTen = new String[n];
            System.out.println("===Nhap gia tri cho mang chuoi===");
            for (int i = 0; i < n; i++) {
                System.out.print("Phan tu thu " + i + ": ");
                mangTen[i] = input.readLine();
            }
            //Xuat mang vua nhap
            xuatMang(mangTen);

            //Cho nguoi dung nhap 1 ten bat ky va tim trong mang xem...
            //...co phan tu do khong?
            System.out.println("===Kiem tra ten bat ky co nam trong mangTen===");
            System.out.print("Nhap vao ten bat ky: ");
            String ten = input.readLine();
            //Tim kiem va tra ve vi tri dau tien...
            if (kiemTraTonTai(ten, mangTen) == -1) {
                System.out.println("KHONG co ten vua nhap trong mangTen");
            } else {
                System.out.println(ten + " xuat hien trong mangTen tai vi tri: " + kiemTraTonTai(ten, mangTen));
            }

            //==Yeu cau2: Tim va in ra nhung phan tu trong do co ky tu "n" trong mangTen
            System.out.println("===Kiem tra chuoi co ky tu \"n\"===");
            for (int i = 0; i < n; i++) {
                if (mangTen[i].contains("n")) {
                    System.out.println(mangTen[i]);
                }
            }
            //==Yeu cau3: Sap xep mang theo thu tu tang dan theo alphabet. In ra==
            for (int i = 0; i < n - 1; i++) {
                if (mangTen[i].compareTo(mangTen[i + 1]) > 0) {
                    String temp = mangTen[i];
                    mangTen[i] = mangTen[i + 1];
                    mangTen[i + 1] = temp;
                }
            }
            //Xuat mang
            System.out.println("===Mang sau khi sap xep tang dan===");
            for (int i = 0; i < n; i++) {
                System.out.println(mangTen[i]);
            }
            System.out.println("");
        } catch (Exception ex) {
            System.out.println("Err: ");
        }
    }

    public static int kiemTraTonTai(String ten, String[] mangTen) {
        int vitri = -1;
        for (int i = 0; i < mangTen.length; i++) {
            if (ten.equals(mangTen[i])) {
                vitri = i;
                break;
            }
        }
        return vitri;
    }

    public static void xuatMang(String[] arr) {
        for (String i : arr) {
            System.out.println(i);
        }
    }

}
