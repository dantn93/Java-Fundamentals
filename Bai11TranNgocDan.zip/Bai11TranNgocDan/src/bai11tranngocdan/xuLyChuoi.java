/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class xuLyChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi s1: ");
            StringBuilder s1 = new StringBuilder(input.readLine());

            System.out.print("Nhap chuoi s2: ");
            StringBuilder s2 = new StringBuilder(input.readLine());

            System.out.print("Nhap chuoi s3: ");
            StringBuilder s3 = new StringBuilder(input.readLine());

            System.out.print("Nhap vi tri v: ");
            int v = Integer.parseInt(input.readLine());

            //Chieu dai chuoi
            System.out.println("Chieu dai chuoi s1: " + s1.length());
            System.out.println("Chieu dai chuoi s2: " + s2.length());
            System.out.println("Chieu dai chuoi s3: " + s3.length());
            System.out.println("Ket qua so s1 & s2: " + s1.toString().compareTo(s2.toString()));
            System.out.println("Vi tri xuat hien dau tien cua chuoi s3 trong s1: " + s1.toString().indexOf(s3.toString()));
            //Tao s4 tu chuoi s1 co vi tri tu v.
            StringBuilder s4 = new StringBuilder(s1.toString().substring(v));
            System.out.println("Chuoi s4: "+s4.toString());
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
