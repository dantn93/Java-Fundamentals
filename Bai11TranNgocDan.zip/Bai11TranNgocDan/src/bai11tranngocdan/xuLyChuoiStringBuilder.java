/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author snow
 */
public class xuLyChuoiStringBuilder {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi sb: ");
            StringBuilder sb = new StringBuilder(input.readLine());
            System.out.print("Nhap chuoi sb1: ");
            StringBuilder sb1 = new StringBuilder(input.readLine());
            System.out.print("Nhap chuoi sb2: ");
            StringBuilder sb2 = new StringBuilder(input.readLine());
            System.out.print("Nhap chuoi sb3: ");
            StringBuilder sb3 = new StringBuilder(input.readLine());
            System.out.print("Nhap chuoi sb4: ");
            StringBuilder sb4 = new StringBuilder(input.readLine());

            //Xuat chieu dai chuoi
            System.out.println("====================================");
            System.out.println("Chieu dai chuoi sb: " + sb.length());
            System.out.println("Chieu dai chuoi sb1: " + sb1.length());
            System.out.println("Chieu dai chuoi sb2: " + sb2.length());
            System.out.println("Chieu dai chuoi sb3: " + sb3.length());
            System.out.println("Chieu dai chuoi sb4: " + sb4.length());
            System.out.println("====================================");
            //Noi chuoi sb1 vao sau chuoi sb => Xuat chuoi sb luc nay
            System.out.println("Noi chuoi sb1 vao sb: " + sb.append(sb1));
            System.out.println("====================================");
            //Chen chuoi b2 vao chuoi sb tai vi tri vt
            System.out.print("Chen chuoi b2 vao chuoi sb tai vi tri: ");
            int vt = Integer.parseInt(input.readLine());
            while (true) {
                if (vt > sb.length()) {
                    System.out.print("Vi tri chen nam ben ngoai pham vi chuoi sb!\nXin hay nhap lai: ");
                    vt = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            System.out.println("====================================");
            System.out.println("Chuoi sb sau khi chen sb2 tai vi tri " + vt + ": " + sb.insert(vt, sb2));
            //Xoa noi dung sb
            System.out.println("====================================");
            System.out.print("Xoa chuoi sb tu vi tri: ");
            int dau = Integer.parseInt(input.readLine());
            while (true) {
                if (dau >= sb.length()) {
                    System.out.print("Vi tri nam ben ngoai pham vi chuoi sb!\nXin hay nhap lai: ");
                    dau = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            System.out.print("den vi tri: ");
            int cuoi = Integer.parseInt(input.readLine());
            while (true) {
                if (cuoi > sb.length()) {
                    System.out.print("Vi tri nam ben ngoai pham vi chuoi sb!\nXin hay nhap lai: ");
                    cuoi = Integer.parseInt(input.readLine());
                } else {
                    break;
                }
            }
            if (dau > cuoi) {
                int temp = dau;
                dau = cuoi;
                cuoi = temp;
            }
            if (dau < cuoi) {
                System.out.println("Chuoi sb sau khi xoa: " + sb.delete(dau, cuoi));
            } else {
                System.out.println("Chuoi sb sau khi xoa: "+ sb.deleteCharAt(dau));
            }
            //Dao nguoc chuoi sb
            System.out.println("====================================");
            System.out.println("Dao nguoc chuoi sb: "+sb.reverse());
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
