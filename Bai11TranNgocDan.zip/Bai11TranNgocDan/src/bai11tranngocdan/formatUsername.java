/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class formatUsername {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap Username: ");
            StringBuilder str = new StringBuilder(input.readLine());
            
            String regexp = "^[0-9a-z_-]{6,20}$";
            Pattern pattern = Pattern.compile(regexp);
            Matcher matcher = pattern.matcher(str);
            if(matcher.find()){
                System.out.println("=> Username hop le");
            }
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
