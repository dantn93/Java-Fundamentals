/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author hocvien
 */
public class soSanhStringBuilderTuCharVaString {
final static int MAX = 100000;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi s: ");
            String s = input.readLine();

            System.out.print("Nhap chuoi sb: ");
            StringBuilder sb = new StringBuilder(input.readLine());

            System.out.println("Chieu dai chuoi S: " + s.length());
            System.out.println("Chieu dai chuoi Sb: " + sb.length());

            //===Them chuoi String
            double tgS = 0;
            double tgSb = 0;
            char c = 'A';
            String str = "A";
            double bd = System.currentTimeMillis();
            for (int i = 0; i < MAX; i++) {
                s += c;
            }
            double kt = System.currentTimeMillis();
            tgS = kt - bd;
            System.out.println("Thoi gian thuc hien S: " + tgS + " miliseconds");

            //===Them chuoi StringBuilder
            bd = System.currentTimeMillis();
            for (int i = 0; i < MAX; i++) {
                sb.append(str);
            }
            kt = System.currentTimeMillis();
            tgSb = kt - bd;
            System.out.println("Thoi gian thuc hien Sb: " + tgSb + " miliseconds");
            
            //===So sanh ket qua
            if (tgS == tgSb) {
                System.out.println("2 qua trinh co cung thoi gian");
            } else if (tgS < tgSb) {
                System.out.println("Thoi gian s nhanh hon sb");
            } else {
                System.out.println("Thoi gian sb nhanh hon s");
            }

        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
