/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author hocvien
 */
public class phanTachChuoi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi can phan tach: ");
            StringBuilder str = new StringBuilder(input.readLine());

            System.out.print("Nhap ky tu phan tach: ");
            StringBuilder pt = new StringBuilder(input.readLine());
            
            StringTokenizer tkn = new StringTokenizer(str.toString(), pt.toString());
            System.out.println("Cac token: ");
            while(tkn.hasMoreTokens()){
                System.out.println(tkn.nextToken());
            }
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
