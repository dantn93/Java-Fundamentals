/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author hocvien
 */
public class formatDate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap ngay thang nam (dd/mm/yyyy): ");
            StringBuilder str = new StringBuilder(input.readLine());

            String regexp = "^[0-9]?[0-9]/[0-9]?[0-9]/[0-9]+$";
            Pattern pattern = Pattern.compile(regexp);
            Matcher matcher = pattern.matcher(str);

            if (matcher.find()) {
                //Ten tap tin hop le theo dinh dang dd/mm/yyyy...
                //...nhung KHONG dung theo ngay thang trong thuc te
                StringTokenizer tkn = new StringTokenizer(str.toString(), "/");
                int ngay = Integer.parseInt(tkn.nextToken());
                int thang = Integer.parseInt(tkn.nextToken());
                int nam = Integer.parseInt(tkn.nextToken());
                //Kiem tra ngay thang nam hop le
                if (ktNgayThangNam(ngay, thang, nam)) {
                    System.out.println("Ngay hop le");
                } else {
                    System.out.println("Ngay KHONG hop le");
                }

            } else {
                System.out.println("=> Ngay KHONG hop le");
            }
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }

    }

    public static boolean ktNgayThangNam(int ngay, int thang, int nam) {
        if(ngay <= 0)throw new ArithmeticException("Ngay <=  0!");
        if(thang <= 0)throw new ArithmeticException("Ngay <=  0!");
        if(nam <= 0)throw new ArithmeticException("Ngay <=  0!");
        int NGAYTRONGTHANG2 = 0;
        if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0)) {
            NGAYTRONGTHANG2 = 29;
        } else {
            NGAYTRONGTHANG2 = 28;
        }
        switch (thang) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                if (ngay <= 0 || ngay > 31) {
                    return false;
                }
            case 2:
                if (ngay <= 0 || ngay > NGAYTRONGTHANG2) {
                    return false;
                }

            case 4:
            case 6:
            case 9:
            case 11:
                if (ngay <= 0 || ngay > 30) {
                    return false;
                }
        }
        return true;
    }

}
