/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author snow
 */
public class phanTachNgayThangNam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap chuoi ngay thang nam (dd-MM-yyyy): ");
            StringBuilder str = new StringBuilder(input.readLine());

            StringTokenizer ntn = new StringTokenizer(str.toString(), "-");
            StringBuilder ngay = new StringBuilder(ntn.nextToken());
            StringBuilder thang = new StringBuilder(ntn.nextToken());
            StringBuilder nam = new StringBuilder(ntn.nextToken());
            
            System.out.println("Ngay: "+ngay);
            System.out.println("Thang: "+thang);
            System.out.println("Nam: "+nam);

        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }

}
