/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

/**
 *
 * @author snow
 */
public class phanTachHoTen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap ho ten: ");
            StringBuilder str = new StringBuilder(input.readLine());

            StringTokenizer hoTen = new StringTokenizer(str.toString());
            int count = hoTen.countTokens();
            StringBuilder ho = new StringBuilder("");
            StringBuilder tenDem = new StringBuilder("");
            StringBuilder ten = new StringBuilder("");
            //ho
            if (hoTen.hasMoreTokens()) {
                ho = new StringBuilder(hoTen.nextToken());
            }
            //Ten dem
            for(int i=0;i<count-2;i++){
                if(hoTen.hasMoreTokens()){
                    tenDem.append(hoTen.nextToken());
                    tenDem.append(" ");
                }
            }
            //ten
            if(hoTen.hasMoreTokens()){
                ten.append(hoTen.nextToken());
            }
            //In ra console
            InHoTen(ho,tenDem,ten);
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }
    public static void InHoTen(StringBuilder ho, StringBuilder dem, StringBuilder ten)
    {
        System.out.println("Ho: "+ho);
        System.out.println("Ten dem: "+dem);
        System.out.println("Ten: "+ten);
    }

}
