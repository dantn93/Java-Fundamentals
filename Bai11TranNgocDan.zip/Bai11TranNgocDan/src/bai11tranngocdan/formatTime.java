/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bai11tranngocdan;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author snow
 */
public class formatTime {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Nhap gio: ");
            StringBuilder str = new StringBuilder(input.readLine());

            String regrexp1 = "(^[0-1][0-9]:[0-5][0-9]$)|(^2[0-3]:[0-5][0-9]$)";
            Pattern p = Pattern.compile(regrexp1);
            Matcher m = p.matcher(str);

            if (m.find()) {
                System.out.println("Gio hop le");
            } else {
                System.out.println("Gio KHONG hop le");
            }
        } catch (Exception ex) {
            System.out.println("Err: " + ex.getMessage());
        }
    }
}
